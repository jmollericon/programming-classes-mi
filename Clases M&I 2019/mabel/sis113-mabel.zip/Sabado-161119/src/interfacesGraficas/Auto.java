package interfacesGraficas;



public class Auto {
	private String ci;
	private String nombre;
	private String placa;
	public Auto(String ci, String nombre, String placa) {
		super();
		this.ci = ci;
		this.nombre = nombre;
		this.placa = placa;
	}
	
	
	
}
