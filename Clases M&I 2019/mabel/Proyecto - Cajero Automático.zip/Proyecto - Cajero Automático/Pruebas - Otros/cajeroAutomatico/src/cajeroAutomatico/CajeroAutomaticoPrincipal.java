package cajeroAutomatico;
import java.awt.Container;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JFrame;

public class CajeroAutomaticoPrincipal {
    public static void main(String[] args) throws FileNotFoundException, IOException {
    	// ------------------- INTERFAZ GR�FICA --------------------------
    	InterfazCajeroAutom�tico i = new InterfazCajeroAutom�tico();
    	i.setVisible(true);    	
    	
    	// Creamos un vector de 'Cuenta'
    	int n = 5; // N�mero de cuentas
    	Cuenta c[] = new Cuenta[n];
    	
        try {
            File archivo = new File ("datos.txt");
            FileReader fr = new FileReader (archivo);
            BufferedReader br = new BufferedReader(fr);

            String linea;
            String[] parts = null;
            int cont=0;
            while((linea = br.readLine()) != null) {
            	parts = linea.split("\t"); 
            	/* NOMBRE 			= parts[0];
            	 * APELLIDO 		= parts[1];
            	 * CI 				= parts[2];
            	 * NRO_CUENTA 		= parts[3];
            	 * CONTRASE�A 		= parts[4];
            	 * MONTO_INICIAL 	= parts[5]; */
            	c[cont] = new Cuenta(parts[0], parts[1], parts[2], parts[3], parts[4], Double.parseDouble(parts[5]));
                c[cont].mostrar();
                cont++;
            }
            fr.close();
        }
        catch(Exception e) {
            System.out.println("Excepcion leyendo fichero: " + e);
        }
                
    }
}
