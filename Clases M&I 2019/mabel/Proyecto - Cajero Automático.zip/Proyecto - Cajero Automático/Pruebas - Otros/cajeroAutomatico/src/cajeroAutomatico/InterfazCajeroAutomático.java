package cajeroAutomatico;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class InterfazCajeroAutom�tico extends JFrame {
	
	public InterfazCajeroAutom�tico() {
		super("Cajero Autom�tico - Mabel Aguilera");
		setSize(800, 600); // ancho alto de la ventana
		//setLayout(new GridLayout(1,1));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		FlowLayout layout = new FlowLayout(FlowLayout.LEFT, 150, 250);
	    setLayout(layout);
	 
	    // PANEL
	    JPanel teclado = new JPanel(layout);
	    teclado.setBackground(Color.ORANGE);
	    teclado.setPreferredSize(new Dimension(300, 200));

		GridLayout gl = new GridLayout(4,3);
		gl.setHgap(5); gl.setVgap(5);
		teclado.setLayout(gl);
		for(int i = 1; i <= 9; i++) {
			teclado.add(new JButton(String.valueOf(i)));
		}
		teclado.add(new JButton("CANCELAR"));
		teclado.add(new JButton("0"));
		teclado.add(new JButton("ACEPTAR"));

		add(teclado);
	}
}

