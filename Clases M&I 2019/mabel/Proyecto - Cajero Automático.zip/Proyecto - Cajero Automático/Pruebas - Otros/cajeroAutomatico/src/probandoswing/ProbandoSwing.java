package probandoswing;
import java.awt.EventQueue;
public class ProbandoSwing {
    public static void main(String[] args) {
        EventQueue.invokeLater(new VentanaMain());
    }
}