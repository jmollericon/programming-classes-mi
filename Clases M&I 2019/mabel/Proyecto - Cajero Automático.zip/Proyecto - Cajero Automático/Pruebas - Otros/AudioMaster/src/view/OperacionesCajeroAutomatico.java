package view;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;


import procesos.Cuenta;

public class OperacionesCajeroAutomatico extends JFrame {
	private BorderLayout contentPane;
	private JPanel menu;
	private JTextField txtNroCuenta;
	private JTextField txtConstrasena;
	private JButton saldo;
	private JButton retiro;
	private JButton deposito;
	private JButton salir;

	public OperacionesCajeroAutomatico(final Cuenta c[], final int i) {
		super("Cajero Autom�tico - Mabel Aguilera");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new BorderLayout();
		
		menu = new JPanel();
	    menu.setBackground(Color.ORANGE);
	    menu.setPreferredSize(new Dimension(450, 340));
	    
		JLabel msj = new JLabel("<html><body><br>ELIJA LA OPERACION A REALIZAR<br><br><br></body></html>");
		msj.setFont(new Font("Verdana", Font.BOLD, 22));
		JLabel espacio = new JLabel("<html><body><br>&nbsp;<br><br></body></html>");
		espacio.setFont(new Font("Verdana", Font.BOLD, 20));
		
		JLabel nroCuenta 	= new JLabel("Nro: de Cuenta: ");
		nroCuenta.setFont(new Font("Verdana", Font.BOLD, 20));
		JLabel contrasena 	= new JLabel("Contrase�a: ");
		contrasena.setFont(new Font("Verdana", Font.BOLD, 20));
		
		txtNroCuenta = new JTextField();
		txtNroCuenta.setColumns(10);
		txtNroCuenta.setFont(new Font("Verdana", Font.PLAIN, 18));
		
		txtConstrasena = new JPasswordField();
		txtConstrasena.setColumns(10);
		txtConstrasena.setFont(new Font("Verdana", Font.PLAIN, 18));

		saldo = new JButton("SALDO");
		saldo.setPreferredSize(new Dimension(180, 80));
		saldo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c[i].mostrar();
				JOptionPane.showMessageDialog(null, "Nombre: "+c[i].getNomCompleto()+"\nCI: "+c[i].getCI()+"\nNro. de Cuenta: "+c[i].getNroCuenta()+"\nSaldo: "+c[i].getMonto()+" Bs.");
			}
		});
		retiro = new JButton("RETIRO");
		retiro.setPreferredSize(new Dimension(180, 80));
		retiro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double montoRetiro = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el monto a Retirar:"));
				if(montoRetiro > c[i].getMonto()) {
					JOptionPane.showMessageDialog(null, "No tiene saldo suficiente.");
				}else {
					c[i].setMonto(c[i].getMonto()-montoRetiro);
					JOptionPane.showMessageDialog(null, "Retiro realizado satisfactoriamente.");
				}
				
			}
		});
		deposito = new JButton("DEPOSITO");
		deposito.setPreferredSize(new Dimension(180, 80));
		deposito.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double montoDeposito = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el monto a Depositar:"));
				c[i].setMonto(c[i].getMonto()+montoDeposito);
				JOptionPane.showMessageDialog(null, "Dep�sito realizado satisfactoriamente.");
				//ingresarSistema(txtNroCuenta.getText(), txtConstrasena.getText());
			}
		});
		salir = new JButton("SALIR");
		salir.setPreferredSize(new Dimension(180, 80));
		salir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Gracias por su visita.");
				CajeroAutomatico login = new CajeroAutomatico(c);
				dispose(); // CERRAR VENTANA
				login.setVisible(true); // hacer visible la ventana
			}
		});

		menu.add(msj);
		menu.add(saldo);
		menu.add(retiro);
		menu.add(deposito);
		menu.add(salir);
		add(menu);
	}
}
