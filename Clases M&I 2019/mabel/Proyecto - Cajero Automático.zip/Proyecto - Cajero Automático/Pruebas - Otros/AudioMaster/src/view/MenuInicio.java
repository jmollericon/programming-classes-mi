package view;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.Comparator;
import java.util.List;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import procesos.Cuenta;
public class MenuInicio extends JFrame {

	private Cuenta c[];
	private JPanel contentPane;
	private JButton btnIniciar;
	
	
	public static void main(String[] args) {
		MenuInicio frame = new MenuInicio();
		frame.setVisible(true);
	}
	public MenuInicio() {
		int n = 5; // N�mero de cuentas
    	c = new Cuenta[n];
    	
        try {
            File archivo = new File ("datos.txt");
            FileReader fr = new FileReader (archivo);
            BufferedReader br = new BufferedReader(fr);

            String linea;
            String[] parts = null;
            int cont=0;
            while((linea = br.readLine()) != null) {
            	parts = linea.split("\t"); 
            	/* NOMBRE 			= parts[0];
            	 * APELLIDO 		= parts[1];
            	 * CI 				= parts[2];
            	 * NRO_CUENTA 		= parts[3];
            	 * CONTRASE�A 		= parts[4];
            	 * MONTO_INICIAL 	= parts[5]; */
            	this.c[cont] = new Cuenta(parts[0], parts[1], parts[2], parts[3], parts[4], Double.parseDouble(parts[5]));
                this.c[cont].mostrar();
                cont++;
            }
            fr.close();
        }
        catch(Exception e) {
            System.out.println("Excepcion leyendo fichero: " + e);
        }		
		
		
		
		//OperacionesCajeroAutomatico ope = new OperacionesCajeroAutomatico(c);
		//ope.setVisible(true); // hacer visible la ventana
		
		
		//super("Cajero Autom�tico - Mabel Aguilera");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		//contentPane = new JPanel();
		BorderLayout contentPane = new BorderLayout();
		//contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		//setContentPane(contentPane);
		
		// ------------------ MENU INICIO ----------------------
	    JPanel inicio = new JPanel();
	    inicio.setBackground(Color.ORANGE);
	    inicio.setPreferredSize(new Dimension(450, 340));

		btnIniciar = new JButton("INICIAR");
		btnIniciar.setPreferredSize(new Dimension(120, 80));
		btnIniciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//System.out.println(txtUsr.getText());
				//Usuari usr = new Usuari("Jorge", "2019", (float) 550.50);
				CajeroAutomatico login = new CajeroAutomatico(c);
				dispose(); // CERRAR VENTANA
				login.setVisible(true); // hacer visible la ventana
			}
		});
		
		JLabel titulo = new JLabel("<html><body><br>UNIVERSIDAD CAT�LICA<br>BOLIVIANA 'SAN PABLO'<br><br></body></html>");
		titulo.setFont(new Font("Verdana", Font.BOLD, 22));
		JLabel nombre = new JLabel("Univ. Mabel Aguilera");
		nombre.setFont(new Font("Verdana", Font.PLAIN, 20));
		JLabel espacio = new JLabel("<html><body><br>&nbsp;</body></html>");
		espacio.setFont(new Font("Verdana", Font.BOLD, 20));		
		JLabel nomSistema = new JLabel(" Sistema: CAJERO AUTOM�TICO ");
		nomSistema.setFont(new Font("Verdana", Font.BOLD, 20));
		

		inicio.add(titulo);
		inicio.add(nombre);
		//inicio.add(espacio);
		inicio.add(nomSistema);
		inicio.add(espacio);
		inicio.add(btnIniciar);
		add(inicio);		
	}
}
