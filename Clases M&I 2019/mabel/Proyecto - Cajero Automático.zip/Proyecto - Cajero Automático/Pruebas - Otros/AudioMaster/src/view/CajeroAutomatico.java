package view;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;


import procesos.Cuenta;

public class CajeroAutomatico extends JFrame {
	private BorderLayout contentPane;
	private JPanel menu;
	private JTextField txtNroCuenta;
	private JTextField txtConstrasena;
	
	private JButton btnIniciar;

	public CajeroAutomatico(final Cuenta c[]) {
		super("Cajero Autom�tico - Mabel Aguilera");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new BorderLayout();
		
		menu = new JPanel();
	    menu.setBackground(Color.ORANGE);
	    menu.setPreferredSize(new Dimension(450, 340));
	    
		JLabel msj = new JLabel("<html><body><br>INGRESE SU NRO. DE CUENTA<br>&nbsp;E INGRESE SU CONTRASE�A<br><br></body></html>");
		msj.setFont(new Font("Verdana", Font.BOLD, 22));
		JLabel espacio = new JLabel("<html><body><br>&nbsp;<br><br></body></html>");
		espacio.setFont(new Font("Verdana", Font.BOLD, 20));
		
		JLabel nroCuenta 	= new JLabel("Nro: de Cuenta: ");
		nroCuenta.setFont(new Font("Verdana", Font.BOLD, 20));
		JLabel contrasena 	= new JLabel("Contrase�a: ");
		contrasena.setFont(new Font("Verdana", Font.BOLD, 20));
		
		txtNroCuenta = new JTextField();
		txtNroCuenta.setColumns(10);
		txtNroCuenta.setFont(new Font("Verdana", Font.PLAIN, 18));
		
		txtConstrasena = new JPasswordField();
		txtConstrasena.setColumns(10);
		txtConstrasena.setFont(new Font("Verdana", Font.PLAIN, 18));

		btnIniciar = new JButton("INGRESAR");
		btnIniciar.setPreferredSize(new Dimension(180, 80));
		btnIniciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ingresarSistema(txtNroCuenta.getText(), txtConstrasena.getText(), c);
			}
		});
				
		menu.add(msj);
		menu.add(nroCuenta);
		menu.add(txtNroCuenta);
		menu.add(contrasena);
		menu.add(txtConstrasena);
		menu.add(espacio);
		menu.add(btnIniciar);
		add(menu);
		
		
		
		
	}
	void ingresarSistema(String nroCuenta, String pass, Cuenta c[]){
		System.out.println(nroCuenta+"-"+pass);
		String nC, ps;
		boolean sw=true;
		for (int i = 0; i < 5; i++) {
			nC = c[i].getNroCuenta();
			ps = c[i].getContrasena();
			if(nC.equals(nroCuenta) && ps.equals(pass)) {
				System.out.println("usuario: "+i);
				OperacionesCajeroAutomatico ope = new OperacionesCajeroAutomatico(c, i);
				dispose(); // CERRAR VENTANA
				ope.setVisible(true); // hacer visible la ventana
				sw=false;
				break;
			}
		}
		if(sw){
			JOptionPane.showMessageDialog(null, "Datos incorrectos.");
		}
		
		//System.out.println(txtUsr.getText());
		//Usuari usr = new Usuari("Jorge", "2019", (float) 550.50);
		//CajeroAutomatico pu = new CajeroAutomatico(usr);
		//dispose(); // CERRAR VENTANA
		//pu.setVisible(true); // hacer visible la ventana		
		
	}

}
