package procesos;
public class Persona {

	// Atributos
	private String nombre;
	private String apellido;
	private String ci;
	
	// Constructor con Par�metros
	public Persona(String nombre, String apellido, String ci) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.ci = ci;
	}
	// M�todos
	public void mostrar(){
		System.out.print("Nombre: "+this.nombre+"\tApellido: "+this.apellido+"\tCI:: "+this.ci);
	}
	public String getNomCompleto() {
		return nombre+" "+apellido;
	}
	public String getCI() {
		return ci;
	}

}
