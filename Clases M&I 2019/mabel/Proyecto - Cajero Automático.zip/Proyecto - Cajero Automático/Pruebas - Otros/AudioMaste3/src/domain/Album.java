package domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Album extends Producte {
	
	private List<Pista> pistes;
	
	public Album() {
		setPistes(new ArrayList<Pista>());
	}
	
	public Album(String codi,String nom,float preu,String iniciDis, String fiDis){
		this.codi = codi;
		this.nom = nom;
		this.preu = preu;
		this.iniciDisponibilitat=iniciDis;
		this.fiDisponibilitat=fiDis;
		setPistes(new ArrayList<Pista>());
	}

	public List<Pista> getPistes() {
		return pistes;
	}

	public void setPistes(List<Pista> pistes) {
		this.pistes = pistes;
	}

}
