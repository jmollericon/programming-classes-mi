package domain;

import java.util.Date;

public class Tema extends Producte {

	private float durada;

	public Tema(float durada, String codi, String nom, float preu, String iniciDis, String fiDis) {
		this.codi = codi;
		this.nom = nom;
		this.preu = preu;
		this.iniciDisponibilitat=iniciDis;
		this.fiDisponibilitat=fiDis;
		this.setDurada(durada);
	}

	public float getDurada() {
		return durada;
	}

	public void setDurada(float durada) {
		this.durada = durada;
	}
	
	
	
}
