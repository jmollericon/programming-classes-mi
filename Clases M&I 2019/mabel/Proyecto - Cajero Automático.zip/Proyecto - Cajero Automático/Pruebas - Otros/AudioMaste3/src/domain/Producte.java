package domain;

import java.util.Date;

public class Producte {

	protected String codi;
	protected String nom;
	protected float preu;
	protected String iniciDisponibilitat;
	protected String fiDisponibilitat;
	
	public String getCodi() {
		return codi;
	}
	public void setCodi(String codi) {
		this.codi = codi;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public float getPreu() {
		return preu;
	}
	public void setPreu(float preu) {
		this.preu = preu;
	}
	public String getIniciDisponibilitat() {
		return iniciDisponibilitat;
	}
	public void setIniciDisponibilitat(String iniciDisponibilitat) {
		this.iniciDisponibilitat = iniciDisponibilitat;
	}
	public String getFiDisponibilitat() {
		return fiDisponibilitat;
	}
	public void setFiDisponibilitat(String fiDisponibilitat) {
		this.fiDisponibilitat = fiDisponibilitat;
	}
	
	
}
