package domain;

public class Item {
	
	private Producte producte;
	
	public Item(Producte producte){
		this.setProducte(producte);
	}

	public Producte getProducte() {
		return producte;
	}

	public void setProducte(Producte producte) {
		this.producte = producte;
	}
}
