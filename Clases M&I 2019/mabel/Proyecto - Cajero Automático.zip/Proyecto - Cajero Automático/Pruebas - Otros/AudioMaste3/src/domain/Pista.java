package domain;

import java.util.ArrayList;
import java.util.List;

public class Pista {

	private Tema temes;
	
	public Pista(Tema t){
		this.setTema(t);
	}

	public Tema getTema() {
		return temes;
	}

	public void setTema(Tema temes) {
		this.temes = temes;
	}
}
