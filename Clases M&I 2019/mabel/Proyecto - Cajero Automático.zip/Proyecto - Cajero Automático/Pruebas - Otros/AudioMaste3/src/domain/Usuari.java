package domain;

import java.util.ArrayList;
import java.util.List;

public class Usuari {
	
	private String nom;
	private String password;
	private float saldo;
	private List<Compra> compres;
	
	public Usuari(String nom, String password, float saldo) {
		super();
		this.nom = nom;
		this.password = password;
		this.saldo = saldo;
		compres = new ArrayList<Compra>();
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public float getSaldo() {
		return saldo;
	}
	public void setSaldo(float saldo) {
		this.saldo = saldo;
	}
	public List<Compra> getCompres() {
		return compres;
	}
	public void setCompres(List<Compra> compres) {
		this.compres = compres;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public void anadeCompra(Compra compra){
		compres.add(compra);
	}

	
}
