package domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Compra {
	
	private float total;
	private Date data;
	private List<Item> items;
	
	public Compra(float total, Date data) {
		super();
		this.total = total;
		this.data = data;
		items = new ArrayList<Item>();
	}
	
	public float getTotal() {
		return total;
	}

	public void setTotal(float total) {
		this.total = total;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}
	
	public void anadeItem(Item item){
		items.add(item);
	}
	
}
