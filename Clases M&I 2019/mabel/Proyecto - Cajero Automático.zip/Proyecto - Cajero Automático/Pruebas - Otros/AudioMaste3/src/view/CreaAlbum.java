package view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.freixas.jcalendar.JCalendarCombo;

import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;

import data.DataConnection;
import domain.Album;
import domain.Pista;
import domain.Tema;

/**
 * @author hal
 *
 */
public class CreaAlbum extends JDialog {

	private JPanel contentPane;
	private JTextField txtCodi;
	private JTextField txtNom;
	private JTextField txtPreu;
	private JCalendarCombo cmbIniciDis;
	private JButton btnGuarda;
	private JButton btnCancella;
	private JCalendarCombo cmbFiDis;
	private JTable tableTemes;
	private JTable tableCurrentTemes;
	private Album album;
	private ObjectContainer db = DataConnection.getInstance();
	private boolean creacio;
	private JCheckBox checkFi;
	private List<Album> albumes;
	/**
	 * Create the frame.
	 */
	public CreaAlbum(final boolean creacio, Album Album, List<Album> albumes) {
		setModal(true);
		this.albumes=albumes;
		this.creacio=creacio;
		if(!creacio) this.album=Album;
		else this.album = new Album();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 482, 588);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JLabel lblCodi = new JLabel("Codi:");

		JLabel lblNom = new JLabel("Nom:");

		JLabel lblPreu = new JLabel("Preu:");

		txtCodi = new JTextField();
		if(!creacio) txtCodi.setEditable(false);
		txtCodi.setColumns(10);
		txtCodi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtCodi.setBackground(Color.white);
			}
		});
		
		txtNom = new JTextField();
		txtNom.setColumns(10);

		txtPreu = new JTextField();
		txtPreu.setEditable(false);
		txtPreu.setColumns(10);

		btnCancella = new JButton("Cancel·la");
		btnCancella.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		btnGuarda = new JButton("Guarda");
		btnGuarda.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(compCamp()){
					if(creacio){
						if(!existeAlbum()){
							creaAlbum();
							dispose();
						}else{
							JOptionPane.showMessageDialog(contentPane,"Ya existe el album");
							txtCodi.setBackground(Color.red);
						}
					}else{
						updateAlbum();
						dispose();
					}
				}else{
					JOptionPane.showMessageDialog(contentPane,"Falta omplir algun camp o que el album contingui temes");
				}
			}
		});

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Disponibilitat", TitledBorder.LEADING, TitledBorder.TOP, null, null));

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Temes", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
										.addComponent(lblPreu)
										.addPreferredGap(ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
										.addComponent(txtPreu, GroupLayout.PREFERRED_SIZE, 372, GroupLayout.PREFERRED_SIZE))
										.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
												.addContainerGap(204, Short.MAX_VALUE)
												.addComponent(btnGuarda)
												.addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(btnCancella))
												.addComponent(panel, GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE)
												.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
														.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
																.addComponent(lblNom)
																.addComponent(lblCodi))
																.addPreferredGap(ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
																.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
																		.addComponent(txtCodi)
																		.addComponent(txtNom, GroupLayout.DEFAULT_SIZE, 372, Short.MAX_VALUE)))
																		.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE))
																		.addContainerGap())
				);
		gl_contentPane.setVerticalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblCodi)
								.addComponent(txtCodi, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(ComponentPlacement.RELATED)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
										.addComponent(lblNom)
										.addComponent(txtNom, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(ComponentPlacement.RELATED)
										.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
												.addComponent(lblPreu)
												.addComponent(txtPreu, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
												.addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(panel, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 224, Short.MAX_VALUE)
												.addPreferredGap(ComponentPlacement.RELATED)
												.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
														.addComponent(btnCancella)
														.addComponent(btnGuarda))
														.addContainerGap())
				);

		JScrollPane scrollPane = new JScrollPane();

		JScrollPane scrollPane_1 = new JScrollPane();

		JButton buttonAdd = new JButton(">");
		buttonAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				af();
			}
		});

		JButton buttonRemove = new JButton("<");
		buttonRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				remove();
			}
		});

		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 141, GroupLayout.PREFERRED_SIZE)
					.addGap(59)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING)
						.addComponent(buttonAdd)
						.addComponent(buttonRemove))
					.addGap(39)
					.addComponent(scrollPane_1, GroupLayout.PREFERRED_SIZE, 141, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(56)
							.addComponent(buttonAdd)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(buttonRemove))
						.addComponent(scrollPane_1, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE))
					.addContainerGap())
		);

		tableCurrentTemes = new JTable();
		scrollPane_1.setViewportView(tableCurrentTemes);

		tableTemes = new JTable();
		scrollPane.setViewportView(tableTemes);
		panel_1.setLayout(gl_panel_1);

		JLabel lblInicidis = new JLabel("iniciDis:");

		JLabel lblFidis = new JLabel("fiDis:");

		cmbIniciDis = new JCalendarCombo();

		cmbFiDis = new JCalendarCombo();
		cmbFiDis.setEnabled(false);
		
		checkFi = new JCheckBox("");
		checkFi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				cmbFiDis.setEnabled(checkFi.isSelected());
			}
		});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblInicidis)
						.addComponent(lblFidis))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addComponent(cmbIniciDis, 0, 357, Short.MAX_VALUE)
						.addGroup(Alignment.LEADING, gl_panel.createSequentialGroup()
							.addComponent(checkFi)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(cmbFiDis, GroupLayout.DEFAULT_SIZE, 328, Short.MAX_VALUE)))
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblInicidis)
						.addComponent(cmbIniciDis, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(cmbFiDis, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblFidis)
						.addComponent(checkFi))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		contentPane.setLayout(gl_contentPane);

		tableCurrentTemes.setModel(new DefaultTableModel(new Object[][] {}, new String[] {
				"Codi", "Nom", "Objecte" }));
		scrollPane_1.setViewportView(tableCurrentTemes);
		tableCurrentTemes.removeColumn(tableCurrentTemes.getColumn("Objecte"));

		tableTemes.setModel(new DefaultTableModel(new Object[][] {}, new String[] {
				"Codi", "Nom", "Objecte" }));
		scrollPane.setViewportView(tableTemes);
		tableTemes.removeColumn(tableTemes.getColumn("Objecte"));

		rellenaControls();
	}

	/**
	 * si es tracta d'una modificacio omple els components
	 */
	void rellenaControls(){
		if(!creacio){
			txtNom.setText(album.getNom());
			txtCodi.setText(album.getCodi());
			txtPreu.setText(album.getPreu()+"");
			cmbIniciDis.setDate(obtenDate(album.getIniciDisponibilitat()));
			if(!album.getFiDisponibilitat().equalsIgnoreCase("")) cmbFiDis.setDate(obtenDate(album.getFiDisponibilitat()));
			for (Pista t : album.getPistes()) {
				int numCols = tableCurrentTemes.getModel().getColumnCount();
				Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla

				fila[0] = t.getTema().getCodi();
				fila[1] = t.getTema().getNom();
				fila[2] = t.getTema();

				((DefaultTableModel) tableCurrentTemes.getModel()).addRow(fila);				
			}
		}
		if(creacio){
			txtPreu.setText("0");
		}

		List<Tema> lp = db.query(new Predicate<Tema>() {
			public boolean match(Tema o) {
				return true; //TODO: falta poner sólo los temas habilitados!
			}
		}, new Comparator<Tema>() {
			public int compare(Tema o1, Tema o2) {
				return 0;
			}
		});
		DefaultTableModel modelo = (DefaultTableModel)tableTemes.getModel();
		while (modelo.getRowCount() > 0) modelo.removeRow(0);
		int numCols = modelo.getColumnCount();

		for (Tema tematotal : lp) {
			boolean incloure = true;

			for (Pista p : album.getPistes()) {
				if (tematotal.equals(p.getTema())) {
					incloure = false;
				}
			}

			if (incloure) {
				Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla

				fila[0] = tematotal.getCodi();
				fila[1] = tematotal.getNom();
				fila[2] = tematotal;

				modelo.addRow(fila);
			}
		}
	}

	/**
	 * crea un album
	 */
	void creaAlbum(){
		//String codi,String nom,float preu,Date iniciDis, Date fiDis
		String finala = "";
		if(checkFi.isSelected()) finala = obtenString(cmbFiDis.getDate());
		
		
		Album a = new Album(txtCodi.getText(),txtNom.getText(),Float.parseFloat(txtPreu.getText()),
				obtenString(cmbIniciDis.getDate()),finala);
		int rows = tableCurrentTemes.getModel().getRowCount();
		for (int i = 0; i < rows; i++) {
			Tema t = (Tema)tableCurrentTemes.getModel().getValueAt(i, 2);
			a.getPistes().add(new Pista(t));
		}
		db.store(a);
		db.commit();
	}
	/**
	 * modifica un album
	 */
	void updateAlbum(){
		String finala = "";
		if(checkFi.isSelected()) finala = obtenString(cmbFiDis.getDate());
		
		album.setCodi(txtCodi.getText());
		album.setPreu(Float.parseFloat(txtPreu.getText()));
		album.setNom(txtNom.getText());
		album.setIniciDisponibilitat(obtenString(cmbIniciDis.getDate()));
		album.setFiDisponibilitat(finala);
		album.getPistes().clear();
		int rows = tableCurrentTemes.getModel().getRowCount();
		for (int i = 0; i < rows; i++) {
			Tema t = (Tema)tableCurrentTemes.getModel().getValueAt(i, 2);
			album.getPistes().add(new Pista(t));

		}
		db.store(album.getPistes());
		db.store(album);
		db.commit();
	}

	/**
	 * afegeix temes al album
	 */
	void af(){
		Tema tema = (Tema)tableTemes.getModel().getValueAt(tableTemes.getSelectedRow(), 2);
		int numCols = tableTemes.getModel().getColumnCount();
		Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla

		fila[0] = tema.getCodi();
		fila[1] = tema.getNom();
		fila[2] = tema;


		((DefaultTableModel) tableCurrentTemes.getModel()).addRow(fila);
		float preu=Float.parseFloat(txtPreu.getText());
		preu=preu+tema.getPreu();
		txtPreu.setText(preu+"");
		((DefaultTableModel) tableTemes.getModel()).removeRow(tableTemes.getSelectedRow());
	}

	/**
	 * treu temes del album
	 */
	void remove(){
		Tema tema = (Tema)tableCurrentTemes.getModel().getValueAt(tableCurrentTemes.getSelectedRow(), 2);
		int numCols = tableCurrentTemes.getModel().getColumnCount();
		Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla

		fila[0] = tema.getCodi();
		fila[1] = tema.getNom();
		fila[2] = tema;


		((DefaultTableModel) tableTemes.getModel()).addRow(fila);
		float preu=Float.parseFloat(txtPreu.getText());
		preu=preu-tema.getPreu();
		txtPreu.setText(preu+"");
		((DefaultTableModel) tableCurrentTemes.getModel()).removeRow(tableCurrentTemes.getSelectedRow());
	}
	
	Date obtenDate(String fecha){
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Date date = new Date();
		try {
		    date = formatoDelTexto.parse(fecha);
		} catch (Exception ex) {

		    ex.printStackTrace();

		}
		return date;
	}
	
	String obtenString(Date fecha){
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String data="";
		try {
		    data = formatoDelTexto.format(fecha);
		} catch (Exception ex) {

		    ex.printStackTrace();

		}
		return data;
	}
	
	public boolean compCamp(){
		boolean ret=false;
		
		if(!txtNom.getText().equals("")
			&& !txtCodi.getText().equals("")
			&& tableCurrentTemes.getRowCount()>0
				){
			ret=true;
		}
		
		return ret;
	}
	
	public boolean existeAlbum(){
		boolean ret=false;
		for (int i = 0; i < albumes.size(); i++) {
			if(albumes.get(i).getCodi().equals(txtCodi.getText())){
				ret=true;
			}
		}
		return ret;
	}
}
