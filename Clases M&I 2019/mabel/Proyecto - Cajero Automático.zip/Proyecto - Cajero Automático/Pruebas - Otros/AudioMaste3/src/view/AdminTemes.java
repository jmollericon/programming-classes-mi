package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;

import data.DataConnection;
import domain.Album;
import domain.Compra;
import domain.Tema;

public class AdminTemes extends JDialog {

	private ObjectContainer db = DataConnection.getInstance();
	private JPanel contentPane;
	private JTextField txtNom;
	private JTable tableTemas;
	List<Tema> lp;
	List<Compra> ComprasL;
	List<Album> AlbumL;
	
	
	/**
	 * Create the frame.
	 */
	public AdminTemes() {
		ComprasL = new ArrayList<Compra>();
		lp = new ArrayList<Tema>();
		AlbumL = new ArrayList<Album>();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JLabel lblNom = new JLabel("Nom:");

		txtNom = new JTextField();
		txtNom.setColumns(10);
		txtNom.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					refrescaLista();
				}
			}
		});

		JButton btnCancella = new JButton("Cancel·la");
		btnCancella.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});

		JButton btnElimina = new JButton("Elimina");
		btnElimina.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(tableTemas.getSelectedRow()!=-1){
					borrador();
					refrescaLista();
				}else{
					JOptionPane.showMessageDialog(contentPane,"Selecciona algun Tema");
				}
			}
		});

		JButton btnModifica = new JButton("Modifica");
		btnModifica.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tableTemas.getSelectedRow()!=-1){
					CreaTema ct;
					Tema t = (Tema)tableTemas.getModel().getValueAt(tableTemas.getSelectedRow(), 4);
					ct = new CreaTema(false, t, lp);
					ct.setVisible(true);
					refrescaLista();
				}else{
					JOptionPane.showMessageDialog(contentPane,"Selecciona algun Tema");
				}
			}
		});

		JButton btnAfegeix = new JButton("Afegeix");
		btnAfegeix.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreaTema ct;
				ct = new CreaTema(true, null, lp);
				ct.setVisible(true);
				refrescaLista();
			}
		});

		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblNom)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(txtNom, GroupLayout.DEFAULT_SIZE, 384, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(52)
					.addComponent(btnAfegeix)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnModifica)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnElimina)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnCancella))
				.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 432, Short.MAX_VALUE)
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNom)
						.addComponent(txtNom, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 207, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancella)
						.addComponent(btnElimina)
						.addComponent(btnModifica)
						.addComponent(btnAfegeix)))
		);

		tableTemas = new JTable();
		tableTemas.setModel(new DefaultTableModel(new Object[][] {}, new String[] {
				"Codi", "Nom", "Durada", "Preu", "Objecte" }));
		scrollPane.setViewportView(tableTemas);
		tableTemas.removeColumn(tableTemas.getColumn("Objecte"));
		contentPane.setLayout(gl_contentPane);
		refrescaLista();
	}

	/**
	 * omple la taula amb tots els temes
	 */
	void refrescaLista(){
		ComprasL = db.query(new Predicate<Compra>() {
			public boolean match(Compra o) {
				return true;
			}
		});
		
		AlbumL = db.query(new Predicate<Album>() {
			public boolean match(Album o) {
				return true;
			}
		});
		
		lp = db.query(new Predicate<Tema>() {
			public boolean match(Tema o) {
				return true;
			}
		}, new Comparator<Tema>() {
			public int compare(Tema o1, Tema o2) {
				return o1.getNom().compareTo(o2.getNom());
			}
		});
		//List<Tema> lp = db.queryByExample(Tema.class);

		DefaultTableModel modelo = (DefaultTableModel)tableTemas.getModel();
		while (modelo.getRowCount() > 0) modelo.removeRow(0);
		int numCols = modelo.getColumnCount();
		for (Tema tema : lp) {
			if(!txtNom.getText().equalsIgnoreCase("")){
				if(tema.getNom().toLowerCase().contains(txtNom.getText().toLowerCase())){
					Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
		
					fila[0] = tema.getCodi();
					fila[1] = tema.getNom();
					fila[2] = tema.getDurada();
					fila[3] = tema.getPreu();
					fila[4] = tema;
					
					modelo.addRow(fila);
				}
			}else{
				Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
	
				fila[0] = tema.getCodi();
				fila[1] = tema.getNom();
				fila[2] = tema.getDurada();
				fila[3] = tema.getPreu();
				fila[4] = tema;
				
				modelo.addRow(fila);
			}
		}
	}
	
	void borrador(){
		int resposta = JOptionPane.showConfirmDialog(null, "Segur que vols eliminar?", "Eliminar", JOptionPane.YES_NO_OPTION);
		if (resposta == JOptionPane.YES_OPTION) {
			
			boolean ok= true;
			Tema tema = (Tema)tableTemas.getModel().getValueAt(tableTemas.getSelectedRow(), 4);
			for (Compra c : ComprasL) {
				for (int i = 0; i < c.getItems().size(); i++) {
					if(c.getItems().get(i).getProducte().equals(tema)){
						ok=false;
					}
				}
			}
			for (Album a : AlbumL) {
				for (int i = 0; i < a.getPistes().size(); i++) {
					if(a.getPistes().get(i).getTema().equals(tema)){
						ok=false;
					}
				}
			}
			
			
			if(ok) db.delete(tema);
			else{
				JOptionPane.showMessageDialog(contentPane,"No es pot borrar perque existeix en alguna compra o album");
				tema.setFiDisponibilitat(obtenString(new Date()));
			}
		}
	}
	
	Date obtenDate(String fecha){
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Date date = new Date();
		try {
		    date = formatoDelTexto.parse(fecha);
		} catch (Exception ex) {

		    ex.printStackTrace();

		}
		return date;
	}
	
	String obtenString(Date fecha){
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String data="";
		try {
		    data = formatoDelTexto.format(fecha);
		} catch (Exception ex) {

		    ex.printStackTrace();

		}
		return data;
	}
}
