package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Comparator;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;

import data.DataConnection;
import domain.Usuari;

public class AdminUsers extends JFrame {

	private JPanel contentPane;
	private JTextField txtNom;
	private JButton btnAfegeix;
	private JButton btnModifica;
	private JButton btnElimina;
	private JButton btnCancella;
	private JTable tableUsers;
	private ObjectContainer db = DataConnection.getInstance();
	List<Usuari> lp;

	/**
	 * Create the frame.
	 */
	public AdminUsers() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		btnCancella = new JButton("Cancel·la");
		btnCancella.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		btnElimina = new JButton("Elimina");
		btnElimina.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(tableUsers.getSelectedRow()!=-1){
					borrador();
					refrescaLista();
				}else{
					JOptionPane.showMessageDialog(contentPane,"Selecciona algun Usuari");
				}
			}
		});
		
		btnModifica = new JButton("Modifica");
		btnModifica.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tableUsers.getSelectedRow()!=-1){
					CreaUser cu;
					Usuari u = (Usuari)tableUsers.getModel().getValueAt(tableUsers.getSelectedRow(), 2);
					cu = new CreaUser(false, u, lp);
					cu.setVisible(true);
					refrescaLista();
				}else{
					JOptionPane.showMessageDialog(contentPane,"Selecciona algun Usuari");
				}
			}
		});
		
		btnAfegeix = new JButton("Afegeix");
		btnAfegeix.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreaUser cu = new CreaUser(true, null, lp);
				cu.setVisible(true);
				refrescaLista();
			}
		});
		
		JLabel lblNom = new JLabel("nom:");
		
		txtNom = new JTextField();
		txtNom.setColumns(10);
		txtNom.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					refrescaLista();
				}
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap(21, Short.MAX_VALUE)
					.addComponent(btnAfegeix)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnModifica)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnElimina)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnCancella))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblNom)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(txtNom, GroupLayout.DEFAULT_SIZE, 379, Short.MAX_VALUE))
				.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 432, Short.MAX_VALUE)
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNom)
						.addComponent(txtNom, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 207, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancella)
						.addComponent(btnElimina)
						.addComponent(btnModifica)
						.addComponent(btnAfegeix)))
		);
		
		tableUsers = new JTable();
		tableUsers.setModel(new DefaultTableModel(new Object[][] {}, new String[] {
				"Nom", "Saldo", "Objecte" }));
		scrollPane.setViewportView(tableUsers);
		contentPane.setLayout(gl_contentPane);
		tableUsers.removeColumn(tableUsers.getColumn("Objecte"));
		refrescaLista();
	}
	
	/**
	 * omple la tabla
	 */
	void refrescaLista(){
		lp = db.query(new Predicate<Usuari>() {
			public boolean match(Usuari o) {
				return true;
			}
		}, new Comparator<Usuari>() {
			public int compare(Usuari o1, Usuari o2) {
				return o1.getNom().compareTo(o2.getNom());
			}
		});
		
		//List<Tema> lp = db.queryByExample(Tema.class);

		DefaultTableModel modelo = (DefaultTableModel)tableUsers.getModel();
		while (modelo.getRowCount() > 0) modelo.removeRow(0);
		int numCols = modelo.getColumnCount();
		for (Usuari usr : lp) {
			if(!txtNom.getText().equalsIgnoreCase("")){
				if(usr.getNom().toLowerCase().contains(txtNom.getText().toLowerCase())){
					Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
					
					fila[0] = usr.getNom();
					fila[1] = usr.getSaldo();
					fila[2] = usr;
					
					modelo.addRow(fila);
				}
			}else{
				Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
	
				fila[0] = usr.getNom();
				fila[1] = usr.getSaldo();
				fila[2] = usr;
				
				modelo.addRow(fila);
			}
		}
	}
	
	void borrador(){
		int resposta = JOptionPane.showConfirmDialog(null, "Segur que vols eliminar?", "Eliminar", JOptionPane.YES_NO_OPTION);
		if (resposta == JOptionPane.YES_OPTION) {
			Usuari user = (Usuari)tableUsers.getModel().getValueAt(tableUsers.getSelectedRow(), 2);
			while (user.getCompres().size()>0)user.getCompres().remove(0);
			db.delete(user);
		}
	}
}
