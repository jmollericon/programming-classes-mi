package view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import com.db4o.ObjectContainer;

import data.DataConnection;
import java.awt.CardLayout;
import java.awt.GridLayout;
import javax.swing.JLabel;

public class Generalisimo extends JFrame {

	private JPanel contentPane;
	private ObjectContainer db = DataConnection.getInstance();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Generalisimo frame = new Generalisimo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Generalisimo() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				db.close();
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Administracio", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 206, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(220, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, 248, Short.MAX_VALUE)
					.addContainerGap())
		);
		
		JButton btnTemas = new JButton("Temas");
		btnTemas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AdminTemes at;
				at = new AdminTemes();
				at.setVisible(true);
			}
		});
		
		JButton btnAlbum = new JButton("Albumes");
		btnAlbum.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AdminAlbumes aa = new AdminAlbumes();
				aa.setVisible(true);
			}
		});
		
		JButton btnUser = new JButton("Usuarios");
		btnUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminUsers au = new AdminUsers();
				au.setVisible(true);
			}
		});
		panel.setLayout(new GridLayout(0, 1, 0, 0));
		panel.add(btnTemas);
		panel.add(btnAlbum);
		panel.add(btnUser);
		contentPane.setLayout(gl_contentPane);
	}
}
