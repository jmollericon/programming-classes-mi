package view;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import domain.Compra;
import domain.Producte;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class detailHist extends JFrame {

	private JPanel contentPane;
	private Compra compra;
	private JTable tableDetail;

	/**
	 * Create the frame.
	 */
	public detailHist(Compra compra) {
		this.compra=compra;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnOk, Alignment.TRAILING)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 414, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnOk)
					.addContainerGap())
		);
		
		tableDetail = new JTable();
		tableDetail.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Codi", "Nom"
			}
		));
		scrollPane.setViewportView(tableDetail);
		contentPane.setLayout(gl_contentPane);
		init();
	}
	
	void init(){
		DefaultTableModel modelo = (DefaultTableModel)tableDetail.getModel();
		while (modelo.getRowCount() > 0) modelo.removeRow(0);
		int numCols = modelo.getColumnCount();
		for (int i = 0; i < compra.getItems().size(); i++) {
			Producte prod = compra.getItems().get(i).getProducte();
			
			Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
			
			fila[0] = prod.getCodi();
			fila[1] = prod.getNom();
			
			modelo.addRow(fila);
		}
	}

}
