package view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.EmptyBorder;

import com.db4o.ObjectContainer;

import data.DataConnection;
import domain.Usuari;

public class CreaUser extends JDialog {

	private ObjectContainer db = DataConnection.getInstance();
	private JPanel contentPane;
	private boolean creacio;
	private Usuari user;
	private JTextField txtNom;
	private JSpinner spinSaldo;
	private JPasswordField txtPass;
	private List<Usuari> usuaris;

	/**
	 * Create the frame.
	 * @param lp 
	 */
	public CreaUser(final boolean creacio, Usuari User, List<Usuari> lp) {
		setModal(true);
		this.usuaris=lp;
		this.creacio = creacio;
		if (!creacio)
			this.user = User;

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		txtNom = new JTextField();
		txtNom.setColumns(10);
		txtNom.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtNom.setBackground(Color.white);
			}
		});
		
		JButton btnCancella = new JButton("Cancel·la");
		btnCancella.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		JButton btnGuarda = new JButton("Guarda");
		btnGuarda.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(compCamp(creacio)){
					if (creacio){
						if(!existeUser()){
							anadir();
							dispose();
						}else{
							JOptionPane.showMessageDialog(contentPane,"Ya existe ese usuario");
							txtNom.setBackground(Color.red);
						}
					}else{
						modifica();
						dispose();
					}
				}else{
					JOptionPane.showMessageDialog(contentPane,"Falta omplir algun camp");
				}
			}
		});

		JLabel lblNom = new JLabel("Nom:");

		JLabel lblPassword = new JLabel("Password:");

		JLabel lblSaldo = new JLabel("Saldo:");

		
		spinSaldo = new JSpinner();
		if (creacio)
			spinSaldo.setModel(new SpinnerNumberModel(new Float(1),
					new Float(1), null, new Float(1)));
		else
			spinSaldo.setModel(new SpinnerNumberModel(
					new Float(user.getSaldo()), new Float(user.getSaldo()),
					null, new Float(1)));
		txtPass = new JPasswordField();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane
				.setHorizontalGroup(gl_contentPane
						.createParallelGroup(Alignment.TRAILING)
						.addGroup(
								gl_contentPane
										.createSequentialGroup()
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.LEADING)
														.addGroup(
																gl_contentPane
																		.createSequentialGroup()
																		.addGroup(
																				gl_contentPane
																						.createParallelGroup(
																								Alignment.LEADING)
																						.addComponent(
																								lblPassword)
																						.addComponent(
																								lblSaldo)
																						.addComponent(
																								lblNom))
																		.addPreferredGap(
																				ComponentPlacement.UNRELATED)
																		.addGroup(
																				gl_contentPane
																						.createParallelGroup(
																								Alignment.LEADING)
																						.addComponent(
																								txtPass,
																								GroupLayout.DEFAULT_SIZE,
																								327,
																								Short.MAX_VALUE)
																						.addComponent(
																								spinSaldo,
																								GroupLayout.DEFAULT_SIZE,
																								327,
																								Short.MAX_VALUE)
																						.addComponent(
																								txtNom,
																								GroupLayout.DEFAULT_SIZE,
																								327,
																								Short.MAX_VALUE)))
														.addGroup(
																Alignment.TRAILING,
																gl_contentPane
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				btnGuarda)
																		.addPreferredGap(
																				ComponentPlacement.RELATED)
																		.addComponent(
																				btnCancella)))
										.addContainerGap()));
		gl_contentPane
				.setVerticalGroup(gl_contentPane
						.createParallelGroup(Alignment.TRAILING)
						.addGroup(
								gl_contentPane
										.createSequentialGroup()
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(lblNom)
														.addComponent(
																txtNom,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												ComponentPlacement.UNRELATED)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																lblPassword)
														.addComponent(
																txtPass,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												ComponentPlacement.UNRELATED)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.TRAILING)
														.addComponent(lblSaldo)
														.addComponent(
																spinSaldo,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												ComponentPlacement.RELATED,
												147, Short.MAX_VALUE)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																btnCancella)
														.addComponent(btnGuarda))
										.addContainerGap()));
		contentPane.setLayout(gl_contentPane);
		if (!creacio)
			inicializaControls();
	}

	/**
	 * si es tracta d'una modificacio omple els controls
	 */
	void inicializaControls() {
		txtNom.setText(user.getNom());
		spinSaldo.setValue(user.getSaldo());
	}

	/**
	 * afegeix un usuari
	 */
	void anadir() {
		// float durada, String codi, String nom, float preu, Date iniciDis,
		// Date fiDis
		try {
			Usuari u = new Usuari(txtNom.getText(), MD5(new String(txtPass.getPassword())), 
					(Float) spinSaldo.getValue());
			db.store(u);
			db.commit();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(contentPane,
					"Error al crear l'usuari");
		}
	}

	/**
	 * modifica el usuari
	 */
	void modifica() {
		try {
			user.setNom(txtNom.getText());
			if (!txtPass.getPassword().toString().equalsIgnoreCase(""))
				user.setPassword(MD5(new String(txtPass.getPassword())));
			user.setSaldo((Float) spinSaldo.getValue());
			db.store(user);
			db.commit();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(contentPane,
					"Error al editar l'usuari");
		}
	}

	public String MD5(String password) throws Exception {
		MessageDigest md5;
		md5 = MessageDigest.getInstance("MD5");
		md5.update(password.getBytes());
		BigInteger hash = new BigInteger(1, md5.digest());
		return hash.toString(16);
	}
	
	public boolean compCamp(boolean creacio){
		boolean ret=false;
		if(creacio){
			if(!txtNom.getText().equals("")
				&& !new String(txtPass.getPassword()).equals("")
					){
				ret=true;
			}
		}else if(!creacio){

			if(!txtNom.getText().equals("")
					){
				ret=true;
			}
		}
		
		return ret;
	}
	
	public boolean existeUser(){
		boolean ret=false;
		for (int i = 0; i < usuaris.size(); i++) {
			if(usuaris.get(i).getNom().equals(txtNom.getText())){
				ret=true;
			}
		}
		return ret;
	}
	
}
