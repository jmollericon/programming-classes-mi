package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import com.db4o.ObjectContainer;

import data.DataConnection;
import domain.Usuari;

public class pantallaUser extends JFrame {

	private JPanel contentPane;
	private Usuari usr;
	private JTextField txtSaldo;
	private JTextField txtNom;
	private ObjectContainer db = DataConnection.getInstance();

	/**
	 * Create the frame.
	 */
	public pantallaUser(final Usuari usr) {
		this.usr=usr;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		
		JButton btnHistorialCompres = new JButton("Historial Compres");
		btnHistorialCompres.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Historial h = new Historial(usr);
				h.setVisible(true);
			}
		});
		
		JButton btnNovaCompre = new JButton("Nova Compra");
		btnNovaCompre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NovaCompra nc = new NovaCompra(usr);
				nc.setVisible(true);
				iniciaControls();
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 438, Short.MAX_VALUE)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(btnNovaCompre, GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
					.addGap(266))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(btnHistorialCompres, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGap(266))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnHistorialCompres)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnNovaCompre)
					.addContainerGap(36, Short.MAX_VALUE))
		);
		
		JLabel lblNom = new JLabel("Nom:");
		
		JLabel lblSaldo = new JLabel("Saldo:");
		
		txtSaldo = new JTextField();
		txtSaldo.setEditable(false);
		txtSaldo.setColumns(10);
		
		txtNom = new JTextField();
		txtNom.setEditable(false);
		txtNom.setColumns(10);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblSaldo)
						.addComponent(lblNom))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(txtNom, GroupLayout.PREFERRED_SIZE, 335, GroupLayout.PREFERRED_SIZE)
						.addComponent(txtSaldo, GroupLayout.PREFERRED_SIZE, 335, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(22, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNom)
						.addComponent(txtNom, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblSaldo)
						.addComponent(txtSaldo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(89, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		contentPane.setLayout(gl_contentPane);
		iniciaControls();
	}
	
	/**
	 * omple els components
	 */
	void iniciaControls(){
		txtNom.setText(usr.getNom());
		txtSaldo.setText(usr.getSaldo()+"");
	}
}
