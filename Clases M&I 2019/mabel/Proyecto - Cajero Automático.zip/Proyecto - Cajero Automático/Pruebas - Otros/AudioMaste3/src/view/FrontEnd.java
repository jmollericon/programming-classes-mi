package view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.Comparator;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;

import data.DataConnection;
import domain.Usuari;

public class FrontEnd extends JFrame {

	private ObjectContainer db = DataConnection.getInstance();
	private JPanel contentPane;
	private JTextField txtUsr;
	private JButton btnCancella;
	private JButton btnOk;
	private JPasswordField txtPass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrontEnd frame = new FrontEnd();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrontEnd() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		btnCancella = new JButton("Cancel·la");
		btnCancella.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				intentaLogin();
			}
		});
		
		JLabel lblUsuari = new JLabel("Usuari:");
		
		JLabel lblPassword = new JLabel("Password:");
		
		txtUsr = new JTextField();
		txtUsr.setColumns(10);
		
		txtPass = new JPasswordField();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblUsuari)
								.addComponent(lblPassword))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(txtPass, GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE)
								.addComponent(txtUsr, GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE))
							.addContainerGap())
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnOk)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnCancella))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblUsuari)
						.addComponent(txtUsr, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPassword)
						.addComponent(txtPass, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 162, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancella)
						.addComponent(btnOk)))
		);
		contentPane.setLayout(gl_contentPane);
	}

	/**
	 * intenta fer un login, si va be crea segueix, sino tanca la finestra
	 */
	void intentaLogin(){
		try {
			List<Usuari> lp = db.query(new Predicate<Usuari>() {
				public boolean match(Usuari o) {
					return o.getNom().equals(txtUsr.getText());
				}
			}, new Comparator<Usuari>() {
				public int compare(Usuari o1, Usuari o2) {
					return o1.getNom().compareTo(o2.getNom());
				}
			});
			
			for (Usuari usr : lp) {
				if(usr.getPassword().equals(MD5(new String(txtPass.getPassword())))){
					pantallaUser pu = new pantallaUser(usr);
					pu.setVisible(true);
				}else{
					JOptionPane.showMessageDialog(contentPane,"Login incorrecte");
					dispose();
				}
			}
		}catch (Exception e) {
			JOptionPane.showMessageDialog(contentPane,"Error 42");
		}	
	}
	
	public String MD5(String password) throws Exception {
		MessageDigest md5;
		md5 = MessageDigest.getInstance("MD5");
		md5.update(password.getBytes());
		BigInteger hash = new BigInteger(1, md5.digest());
		return hash.toString(16);
	}
}
