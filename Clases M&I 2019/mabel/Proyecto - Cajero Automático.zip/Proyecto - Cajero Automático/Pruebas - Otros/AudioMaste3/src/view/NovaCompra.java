package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;

import data.DataConnection;
import domain.Album;
import domain.Compra;
import domain.Item;
import domain.Producte;
import domain.Tema;
import domain.Usuari;

public class NovaCompra extends JDialog {

	private JPanel contentPane;
	private Usuari usr;
	private JTextField txtPreu;
	private JButton btnCompra;
	private JButton btnCancella;
	private JTable tableHay;
	private JTable tableCompra;
	private ObjectContainer db = DataConnection.getInstance();
	private List<Producte> listp;
	/**
	 * Create the frame.
	 */
	public NovaCompra(final Usuari usr) {
		listp = new ArrayList<Producte>();
		setModal(true);
		this.usr=usr;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		
		btnCancella = new JButton("Cancel·la");
		btnCancella.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		btnCompra = new JButton("Compra");
		btnCompra.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(usr.getSaldo()>=(Float.parseFloat(txtPreu.getText()))){
					compra();
					dispose();
				}
				else JOptionPane.showMessageDialog(contentPane,"No es pot realitzar la compra. Saldo insuficient");
			}
		});
		
		JLabel lblTotal = new JLabel("Total:");
		
		txtPreu = new JTextField();
		txtPreu.setText("0");
		txtPreu.setEditable(false);
		txtPreu.setColumns(10);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 432, Short.MAX_VALUE)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(235)
					.addComponent(btnCompra)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnCancella))
				.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
					.addComponent(lblTotal)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(txtPreu, GroupLayout.DEFAULT_SIZE, 373, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 185, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTotal)
						.addComponent(txtPreu, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancella)
						.addComponent(btnCompra)))
		);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JScrollPane scrollPane_1 = new JScrollPane();
		
		JButton buttonAdd = new JButton(">");
		buttonAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(tableHay.getSelectedRow()!=-1){
					af();
				}else{
					JOptionPane.showMessageDialog(contentPane,"Selecciona algun Producte");
				}
			}
		});
		
		JButton buttonRem = new JButton("<");
		buttonRem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tableCompra.getSelectedRow()!=-1){
					rem();
				}else{
					JOptionPane.showMessageDialog(contentPane,"Selecciona algun Producte");
				}
			}
		});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 141, GroupLayout.PREFERRED_SIZE)
					.addGap(40)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(buttonAdd)
						.addComponent(buttonRem))
					.addPreferredGap(ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
					.addComponent(scrollPane_1, GroupLayout.PREFERRED_SIZE, 141, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollPane_1, GroupLayout.PREFERRED_SIZE, 161, GroupLayout.PREFERRED_SIZE)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(buttonAdd)
							.addPreferredGap(ComponentPlacement.RELATED, 107, Short.MAX_VALUE)
							.addComponent(buttonRem)))
					.addContainerGap())
		);
		
		tableCompra = new JTable();
		tableCompra.setModel(new DefaultTableModel(new Object[][] {}, new String[] {
				"Nom", "Preu", "Objecte" }));
		scrollPane_1.setViewportView(tableCompra);
		tableCompra.removeColumn(tableCompra.getColumn("Objecte"));
		scrollPane_1.setViewportView(tableCompra);
		
		tableHay = new JTable();
		tableHay.setModel(new DefaultTableModel(new Object[][] {}, new String[] {
				"Nom", "Preu", "Objecte" }));
		scrollPane.setViewportView(tableHay);
		panel.setLayout(gl_panel);
		tableHay.removeColumn(tableHay.getColumn("Objecte"));
		contentPane.setLayout(gl_contentPane);
		inicializaControls();
	}
	
	/**
	 * omple la table amb productes
	 */
	void inicializaControls(){
		List<Album> albumes = db.query(new Predicate<Album>() {
			public boolean match(Album o) {
				return true;
			}
		}, new Comparator<Album>() {
			public int compare(Album o1, Album o2) {
				return o1.getCodi().compareTo(o2.getCodi());
			}
		});
		for (Album album : albumes) {
			listp.add(album);
		}
		
		List<Tema> temas = db.query(new Predicate<Tema>() {
			public boolean match(Tema o) {
				return true;
			}
		}, new Comparator<Tema>() {
			public int compare(Tema o1, Tema o2) {
				return o1.getCodi().compareTo(o2.getCodi());
			}
		});
		
		for (Tema tema : temas) {
			listp.add(tema);
		}
		//List<Tema> lp = db.queryByExample(Tema.class);

		DefaultTableModel modelo = (DefaultTableModel)tableHay.getModel();
		while (modelo.getRowCount() > 0) modelo.removeRow(0);
		int numCols = modelo.getColumnCount();
		for (Producte usr : listp) {
			Date f = obtenDate(obtenString(new Date()));
			if(!usr.getFiDisponibilitat().equals("")){
				if(obtenDate(usr.getFiDisponibilitat()).before(f)){
					Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
			
					fila[0] = usr.getNom();
					fila[1] = usr.getPreu();
					fila[2] = usr;
					
					modelo.addRow(fila);
				}
			}else{
				Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
				
				fila[0] = usr.getNom();
				fila[1] = usr.getPreu();
				fila[2] = usr;
				
				modelo.addRow(fila);
			}
		}
		
	}
	
	Date obtenDate(String fecha){
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Date date = new Date();
		try {
		    date = formatoDelTexto.parse(fecha);
		} catch (Exception ex) {

		    ex.printStackTrace();

		}
		return date;
	}
	
	String obtenString(Date fecha){
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String data="";
		try {
		    data = formatoDelTexto.format(fecha);
		} catch (Exception ex) {

		    ex.printStackTrace();

		}
		return data;
	}
	
	/**
	 * fa la operacio de la compra 
	 */
	void compra(){
		//fa la compra
		Compra compra = new Compra(Float.parseFloat(txtPreu.getText()), new Date());
		int rows = tableCompra.getModel().getRowCount();
		for (int i = 0; i < rows; i++) {
			Producte t = (Producte)tableCompra.getModel().getValueAt(i, 2);
			Item item = new Item(t);
			compra.anadeItem(item);
		}
		usr.anadeCompra(compra);
		usr.setSaldo(usr.getSaldo()-Float.parseFloat(txtPreu.getText()));
		db.store(usr.getCompres());
		db.store(usr);
		db.commit();
	}
	
	void af(){
		Producte tema = (Producte)tableHay.getModel().getValueAt(tableHay.getSelectedRow(), 2);
		int numCols = tableHay.getModel().getColumnCount();
		Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla

		fila[0] = tema.getNom();
		fila[1] = tema.getPreu();
		fila[2] = tema;


		((DefaultTableModel) tableCompra.getModel()).addRow(fila);
		float preu=Float.parseFloat(txtPreu.getText());
		preu=preu+tema.getPreu();
		txtPreu.setText(preu+"");
		((DefaultTableModel) tableHay.getModel()).removeRow(tableHay.getSelectedRow());
	}
	
	void rem(){
		Producte tema = (Producte)tableCompra.getModel().getValueAt(tableCompra.getSelectedRow(), 2);
		int numCols = tableCompra.getModel().getColumnCount();
		Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla

		fila[0] = tema.getNom();
		fila[1] = tema.getPreu();
		fila[2] = tema;


		((DefaultTableModel) tableHay.getModel()).addRow(fila);
		float preu=Float.parseFloat(txtPreu.getText());
		preu=preu-tema.getPreu();
		txtPreu.setText(preu+"");
		((DefaultTableModel) tableCompra.getModel()).removeRow(tableCompra.getSelectedRow());
	}

}
