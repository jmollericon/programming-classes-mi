package view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import org.freixas.jcalendar.JCalendarCombo;

import com.db4o.ObjectContainer;

import data.DataConnection;
import domain.Tema;

public class CreaTema extends JDialog {

	private ObjectContainer db = DataConnection.getInstance();
	private JPanel contentPane;
	private boolean creacio;
	private JTextField txtCodi;
	private JTextField txtNom;
	private JTextField txtPreu;
	private JTextField txtDurada;
	private JCalendarCombo cmbFinal;
	private JCalendarCombo cmbInici;
	private Tema tema;
	private JCheckBox checkFi;
	private List<Tema> temas;

	/**
	 * Create the frame.
	 */
	public CreaTema(final boolean creacio, Tema tema, List<Tema> temas) {
		this.temas=temas;
		setModal(true);
		this.creacio=creacio;
		if(!creacio) this.tema=tema;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 451, 309);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNom = new JLabel("codi:");
		
		txtCodi = new JTextField();
		txtCodi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtCodi.setBackground(Color.white);
			}
		});
		txtCodi.setColumns(10);
		
		JLabel lblNom_1 = new JLabel("nom:");
		
		JLabel lblPreu = new JLabel("preu:");
		
		JLabel lblDurada = new JLabel("durada:");
		
		txtNom = new JTextField();
		txtNom.setColumns(10);
		
		txtPreu = new JTextField();
		txtPreu.setColumns(10);
		
		txtDurada = new JTextField();
		txtDurada.setColumns(10);
		
		JButton btnCancella = new JButton("Cancel·la");
		btnCancella.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		
		JButton btnGuarda = new JButton("Guarda");
		btnGuarda.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(compCampos()){
					if(creacio){
						if(!existeTema()){
							anadir();
							dispose();
						}else{
							JOptionPane.showMessageDialog(contentPane,"Ya existe el tema");
							txtCodi.setBackground(Color.red);
						}
					}
					else{
						modifica();
						dispose();
					}
				}
			}
		});
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Disponibilitat", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblDurada)
						.addComponent(lblPreu)
						.addComponent(lblNom_1)
						.addComponent(lblNom))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(txtCodi, GroupLayout.DEFAULT_SIZE, 358, Short.MAX_VALUE)
						.addComponent(txtNom, GroupLayout.DEFAULT_SIZE, 358, Short.MAX_VALUE)
						.addComponent(txtPreu, GroupLayout.DEFAULT_SIZE, 358, Short.MAX_VALUE)
						.addComponent(txtDurada, GroupLayout.DEFAULT_SIZE, 358, Short.MAX_VALUE)))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(216)
					.addComponent(btnGuarda)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnCancella))
				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 432, Short.MAX_VALUE)
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNom)
						.addComponent(txtCodi, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNom_1)
						.addComponent(txtNom, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPreu)
						.addComponent(txtPreu, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblDurada)
						.addComponent(txtDurada, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancella)
						.addComponent(btnGuarda)))
		);
		
		JLabel lblInici = new JLabel("inici:");
		
		cmbInici = new JCalendarCombo();
		
		cmbFinal = new JCalendarCombo();
		cmbFinal.setEnabled(false);
		
		JLabel lblFinal = new JLabel("final:");
		
		checkFi = new JCheckBox("");
		checkFi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(checkFi.isSelected()) cmbFinal.setEnabled(true);
				else cmbFinal.setEnabled(false);
			}
		});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblInici)
						.addComponent(lblFinal))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(cmbInici, 0, 344, Short.MAX_VALUE)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(checkFi)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(cmbFinal, 0, 344, Short.MAX_VALUE)))
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblInici)
						.addComponent(cmbInici, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(15)
							.addComponent(lblFinal))
						.addGroup(gl_panel.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
								.addComponent(checkFi)
								.addComponent(cmbFinal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))))
					.addContainerGap(167, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		contentPane.setLayout(gl_contentPane);
		
		if(!creacio) inicializaControls();
	}
	
	/**
	 * omple els controls 
	 */
	void inicializaControls(){
		txtNom.setText(tema.getNom());
		txtCodi.setText(tema.getCodi());
		txtDurada.setText(tema.getDurada()+"");
		txtPreu.setText(tema.getPreu()+"");
		cmbInici.setDate(obtenDate(tema.getIniciDisponibilitat()));
		if(!tema.getFiDisponibilitat().equals("")) cmbFinal.setDate(obtenDate(tema.getFiDisponibilitat()));
	}
	
	/**
	 * modifica el tema
	 */
	void modifica(){
		
		String finala = "";
		if(checkFi.isSelected()) finala = obtenString(cmbFinal.getDate());
		
		tema.setCodi(txtCodi.getText());
		tema.setDurada(Float.parseFloat(txtDurada.getText()));
		tema.setNom(txtNom.getText());
		tema.setPreu(Float.parseFloat(txtPreu.getText()));
		tema.setIniciDisponibilitat(obtenString(cmbInici.getDate()));
		tema.setFiDisponibilitat(finala);
		
		db.commit();
	}
	
	/**
	 * crea un tema
	 */
	void anadir(){
		//float durada, String codi, String nom, float preu, Date iniciDis, Date fiDis
		String finala = "";
		if(checkFi.isSelected()) finala = obtenString(cmbFinal.getDate());
		
		Tema t = new Tema(Float.parseFloat(txtDurada.getText()),txtCodi.getText(),txtNom.getText(),Float.parseFloat(txtPreu.getText())
				,obtenString(cmbInici.getDate()),finala);
		db.store(t);
		db.commit();
		
	}
	
	Date obtenDate(String fecha){
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Date date = new Date();
		try {
		    date = formatoDelTexto.parse(fecha);
		} catch (Exception ex) {

		    ex.printStackTrace();

		}
		return date;
	}
	
	String obtenString(Date fecha){
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String data="";
		try {
		    data = formatoDelTexto.format(fecha);
		} catch (Exception ex) {

		    ex.printStackTrace();

		}
		return data;
	}
	
	boolean compCampos(){
		boolean ret = false;
		
		try {
			float preu = Float.parseFloat(txtPreu.getText());
			float durada = Float.parseFloat(txtDurada.getText());
			if(!txtCodi.getText().equalsIgnoreCase("") && !txtNom.getText().equalsIgnoreCase("") ){
				ret=true;
			}else{
				//codi o nom no posat
				JOptionPane.showMessageDialog(contentPane,"Falta algun camp per posar");
			}
		} catch (Exception e) {
			//ha de ser numeric
			JOptionPane.showMessageDialog(contentPane,"El preu i la durada han de ser numerics amb decimals");
		}
		
		return ret;
	}
	
	boolean existeTema(){
		boolean ret=false;
		for (int i = 0; i < temas.size(); i++) {
			if(temas.get(i).getCodi().equals(txtCodi.getText())){
				ret=true;
			}
		}
		return ret;
	}
}
