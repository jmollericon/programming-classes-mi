package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import domain.Compra;
import domain.Usuari;

public class Historial extends JFrame {

	private JPanel contentPane;
	private Usuari usr;
	private JTable tableHist;

	/**
	 * Create the frame.
	 */
	public Historial(Usuari usr) {
		this.usr=usr;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		JButton btnConsulta = new JButton("Consulta");
		btnConsulta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tableHist.getSelectedRow()!=-1){
					Compra compra = (Compra)tableHist.getModel().getValueAt(tableHist.getSelectedRow(), 3);
					detailHist dh = new detailHist(compra);
					dh.setVisible(true);
				}else{
					JOptionPane.showMessageDialog(contentPane,"Selecciona alguna Compra");
				}
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(btnConsulta)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnCancel))
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 414, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancel)
						.addComponent(btnConsulta))
					.addContainerGap())
		);
		
		tableHist = new JTable();
		tableHist.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Data", "Articles", "Import", "Objecte"
			}
		));
		scrollPane.setViewportView(tableHist);
		contentPane.setLayout(gl_contentPane);
		tableHist.removeColumn(tableHist.getColumn("Objecte"));
		
		init();
	}
	
	void init(){
		
		DefaultTableModel modelo = (DefaultTableModel)tableHist.getModel();
		while (modelo.getRowCount() > 0) modelo.removeRow(0);
		int numCols = modelo.getColumnCount();
		
		for (int i = 0; i < usr.getCompres().size(); i++) {
			Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
			
			fila[0] = obtenString(usr.getCompres().get(i).getData());
			fila[1] = usr.getCompres().get(i).getItems().size();
			fila[2] = usr.getCompres().get(i).getTotal();
			fila[3] = usr.getCompres().get(i);
			
			modelo.addRow(fila);
		}
	}
	
	Date obtenDate(String fecha){
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Date date = new Date();
		try {
		    date = formatoDelTexto.parse(fecha);
		} catch (Exception ex) {

		    ex.printStackTrace();

		}
		return date;
	}
	
	String obtenString(Date fecha){
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String data="";
		try {
		    data = formatoDelTexto.format(fecha);
		} catch (Exception ex) {

		    ex.printStackTrace();

		}
		return data;
	}
}
