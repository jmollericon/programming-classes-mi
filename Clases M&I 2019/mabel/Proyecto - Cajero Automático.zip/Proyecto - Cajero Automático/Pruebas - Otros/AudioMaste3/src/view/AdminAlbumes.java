package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;

import data.DataConnection;
import domain.Album;
import domain.Compra;

public class AdminAlbumes extends JDialog {

	private ObjectContainer db = DataConnection.getInstance();
	private JPanel contentPane;
	private JTextField txtNom;
	private JButton btnAfegeix;
	private JButton btnModifica;
	private JButton btnElimina;
	private JButton btnCancella;
	private JTable tableAlbums;
	List<Compra> ComprasL;
	List<Album> lp;

	/**
	 * Create the frame.
	 */
	public AdminAlbumes() {
		ComprasL = new ArrayList<Compra>();
		lp = new ArrayList<Album>();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		btnCancella = new JButton("Cancel·la");
		btnCancella.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		
		btnElimina = new JButton("Elimina");
		btnElimina.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(tableAlbums.getSelectedRow()!=-1){
					borrador();
					refrescaLista();
				}else{
					JOptionPane.showMessageDialog(contentPane,"Selecciona algun Album");
				}
			}
		});
		
		btnModifica = new JButton("Modifica");
		btnModifica.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tableAlbums.getSelectedRow()!=-1){
					Album Album = (Album)tableAlbums.getModel().getValueAt(tableAlbums.getSelectedRow(), 3);
					CreaAlbum ca = new CreaAlbum(false,Album,lp);
					ca.setVisible(true);
					refrescaLista();
				}else{
					JOptionPane.showMessageDialog(contentPane,"Selecciona algun Album");
				}
			}
		});
		
		btnAfegeix = new JButton("Afegeix");
		btnAfegeix.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreaAlbum ca = new CreaAlbum(true,null, lp);
				ca.setVisible(true);
				refrescaLista();
			}
		});
		
		JLabel lblNom = new JLabel("nom:");
		
		txtNom = new JTextField();
		txtNom.setColumns(10);
		txtNom.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					refrescaLista();
				}
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap(27, Short.MAX_VALUE)
					.addComponent(btnAfegeix)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnModifica)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnElimina)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnCancella))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblNom)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(txtNom, GroupLayout.DEFAULT_SIZE, 385, Short.MAX_VALUE))
				.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 438, Short.MAX_VALUE)
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNom)
						.addComponent(txtNom, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancella)
						.addComponent(btnElimina)
						.addComponent(btnModifica)
						.addComponent(btnAfegeix)))
		);
		
		tableAlbums = new JTable();
		scrollPane.setViewportView(tableAlbums);
		contentPane.setLayout(gl_contentPane);
		tableAlbums.setModel(new DefaultTableModel(new Object[][] {}, new String[] {
				"Codi", "Nom", "Preu", "Objecte" }));
		scrollPane.setViewportView(tableAlbums);
		tableAlbums.removeColumn(tableAlbums.getColumn("Objecte"));
		contentPane.setLayout(gl_contentPane);
		refrescaLista();
	}
	
	/**
	 * omple la taula amb els albums
	 */
	void refrescaLista(){
		lp = db.query(new Predicate<Album>() {
			public boolean match(Album o) {
				return true;
			}
		}, new Comparator<Album>() {
			public int compare(Album o1, Album o2) {
				return o1.getNom().compareTo(o2.getNom());
			}
		});
		
		//List<Tema> lp = db.queryByExample(Tema.class);

		
		DefaultTableModel modelo = (DefaultTableModel)tableAlbums.getModel();
		while (modelo.getRowCount() > 0) modelo.removeRow(0);
		int numCols = modelo.getColumnCount();
		for (Album obj : lp) {
			if(!txtNom.getText().equalsIgnoreCase("")){
				if(obj.getNom().toLowerCase().contains(txtNom.getText().toLowerCase())){
					Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
					
					fila[0] = obj.getCodi();
					fila[1] = obj.getNom();
					fila[2] = obj.getPreu();
					fila[3] = obj;
					
					modelo.addRow(fila);
				}
			}else{
				Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
		
				fila[0] = obj.getCodi();
				fila[1] = obj.getNom();
				fila[2] = obj.getPreu();
				fila[3] = obj;
				
				modelo.addRow(fila);
			}
		}
	}
	
	void borrador(){
		int resposta = JOptionPane.showConfirmDialog(null, "Segur que vols eliminar?", "Eliminar", JOptionPane.YES_NO_OPTION);
		if (resposta == JOptionPane.YES_OPTION) {
			Album album = (Album)tableAlbums.getModel().getValueAt(tableAlbums.getSelectedRow(), 3);
			boolean ok= true;
			
			for (Compra c : ComprasL) {
				for (int i = 0; i < c.getItems().size(); i++) {
					if(c.getItems().get(i).getProducte().equals(album)){
						ok=false;
					}
				}
			}
			
			if(ok) db.delete(album);
			else{
				JOptionPane.showMessageDialog(contentPane,"No es pot borrar perque existeix en alguna compra o album");
				album.setFiDisponibilitat(obtenString(new Date()));
			}
		}
	}
	
	Date obtenDate(String fecha){
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Date date = new Date();
		try {
		    date = formatoDelTexto.parse(fecha);
		} catch (Exception ex) {

		    ex.printStackTrace();

		}
		return date;
	}
	
	String obtenString(Date fecha){
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String data="";
		try {
		    data = formatoDelTexto.format(fecha);
		} catch (Exception ex) {

		    ex.printStackTrace();

		}
		return data;
	}
}
