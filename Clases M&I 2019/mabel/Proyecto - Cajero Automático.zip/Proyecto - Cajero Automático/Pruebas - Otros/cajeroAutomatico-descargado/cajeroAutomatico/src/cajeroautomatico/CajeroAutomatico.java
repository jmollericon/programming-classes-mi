package cajeroautomatico;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
public class CajeroAutomatico {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        try {
            File archivo = new File ("datos.txt");
            FileReader fr = new FileReader (archivo);
            BufferedReader br = new BufferedReader(fr);

            String linea;
            while((linea = br.readLine()) != null)
                System.out.println(linea);
 
            fr.close();
        }
        catch(Exception e) {
            System.out.println("Excepcion leyendo fichero: " + e);
        }
                
    }
}
