package prueba;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

public class ManejoArchivosBinarios implements Serializable{
   
	public static void main(String[] args) {
		escribirFichero();
    }
	public static void escribirFichero() {
        FileOutputStream fos = null;
        DataOutputStream salida = null;
        String n = "este es un mensasje";
        try {
            fos = new FileOutputStream("archivoBinario.dat");
            salida = new DataOutputStream(fos);
            salida.writeUTF(n);
            fos.close();
            salida.close();
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (EOFException e) {
            System.out.println("Fin de fichero");
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
	}
}