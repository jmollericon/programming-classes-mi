package proCajeroAutomatico;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class CajeroAutomatico extends JFrame {
	private BorderLayout contentPane;
	private JPanel menu;
	private JTextField txtNroCuenta;
	private JTextField txtConstrasena;
	private JButton btnIniciar;

	public CajeroAutomatico(final Cuenta c[], final int nroCuentas) {
		super("Cajero Autom�tico - Mabel Aguilera");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 200, 500, 400);
		contentPane = new BorderLayout();
		setResizable(false); // tama�o Fijo del Frame
		
		menu = new JPanel();
	    menu.setBackground(Color.ORANGE);
	    menu.setPreferredSize(new Dimension(450, 340));
	    
		JLabel msj = new JLabel("<html><body><br>INGRESE SU NRO. DE CUENTA<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Y SU CONTRASE�A<br><br></body></html>");
		msj.setFont(new Font("Verdana", Font.BOLD, 22));
		JLabel espacio = new JLabel("<html><body><br>&nbsp;<br><br></body></html>");
		espacio.setFont(new Font("Verdana", Font.BOLD, 20));
		
		JLabel nroCuenta 	= new JLabel("Nro: de Cuenta: ");
		nroCuenta.setFont(new Font("Verdana", Font.BOLD, 20));
		JLabel contrasena 	= new JLabel("Contrase�a: ");
		contrasena.setFont(new Font("Verdana", Font.BOLD, 20));
		
		txtNroCuenta = new JTextField();
		txtNroCuenta.setColumns(10);
		txtNroCuenta.setFont(new Font("Verdana", Font.PLAIN, 18));
		
		txtConstrasena = new JPasswordField();
		txtConstrasena.setColumns(10);
		txtConstrasena.setFont(new Font("Verdana", Font.PLAIN, 18));

		btnIniciar = new JButton("INGRESAR");
		btnIniciar.setPreferredSize(new Dimension(180, 80));
		btnIniciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ingresarSistema(txtNroCuenta.getText(), txtConstrasena.getText(), c, nroCuentas);
			}
		});
				
		menu.add(msj);
		menu.add(nroCuenta);
		menu.add(txtNroCuenta);
		menu.add(contrasena);
		menu.add(txtConstrasena);
		menu.add(espacio);
		menu.add(btnIniciar);
		add(menu);
	}
	void ingresarSistema(String nroCuenta, String pass, Cuenta c[], int nroCuentas){
		//System.out.println(nroCuenta+"-"+pass);
		String nC, ps;
		boolean sw=true;
		for (int i = 0; i < nroCuentas; i++) {
			nC = c[i].getNroCuenta();
			ps = c[i].getContrasena();
			if(nC.equals(nroCuenta) && ps.equals(pass)) {
				//System.out.println("usuario: "+i);
				OperacionesCajeroAutomatico ope = new OperacionesCajeroAutomatico(c, i, nroCuentas);
				dispose(); // CERRAR VENTANA
				ope.setVisible(true); // hacer visible la ventana
				sw=false;
				break;
			}
		}
		if(sw){
			JOptionPane.showMessageDialog(null, "Datos incorrectos.");
		}
	}
}
