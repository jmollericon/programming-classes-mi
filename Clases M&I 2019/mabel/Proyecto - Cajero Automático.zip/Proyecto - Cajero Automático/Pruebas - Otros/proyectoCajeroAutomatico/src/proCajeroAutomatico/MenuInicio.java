package proCajeroAutomatico;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import javax.swing.*;

public class MenuInicio extends JFrame {

	private Cuenta c[];
	private JPanel contentPane;
	private JButton btnIniciar;
	private int nroCuentas = 0;
	
	public static void main(String[] args) {
		MenuInicio frame = new MenuInicio();
		frame.setVisible(true);
	}
	public MenuInicio() {
		super("Cajero Autom�tico - Mabel Aguilera");
		int n = 100; // capacidad en n�mero de cuentas
    	c = new Cuenta[n];
        try {
            File archivo = new File ("archivo.txt");
            FileReader fr = new FileReader (archivo);
            BufferedReader br = new BufferedReader(fr);

            String linea;
            String[] parts = null;
            while((linea = br.readLine()) != null) {
            	parts = linea.split("\t"); 
            	/* NOMBRE 			= parts[0];
            	 * APELLIDO 		= parts[1];
            	 * CI 				= parts[2];
            	 * NRO_CUENTA 		= parts[3];
            	 * CONTRASE�A 		= parts[4];
            	 * MONTO_INICIAL 	= parts[5]; */
            	this.c[nroCuentas] = new Cuenta(parts[0], parts[1], parts[2], parts[3], parts[4], Double.parseDouble(parts[5]));
                //this.c[nroCuentas].mostrar();
            	nroCuentas++;
            }
            fr.close();
        }
        catch(Exception e) {
            System.out.println("Excepcion leyendo fichero: " + e);
        }		
	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 200, 500, 400);
		BorderLayout contentPane = new BorderLayout();
		setResizable(false); // tama�o Fijo del Frame
		
		// ------------------ MENU INICIO ----------------------
	    JPanel inicio = new JPanel();
	    inicio.setBackground(Color.ORANGE);
	    inicio.setPreferredSize(new Dimension(450, 340));

		btnIniciar = new JButton("INICIAR");
		btnIniciar.setPreferredSize(new Dimension(120, 80));
		btnIniciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CajeroAutomatico login = new CajeroAutomatico(c, nroCuentas);
				dispose(); 				// CERRAR VENTANA
				login.setVisible(true); // hacer visible la ventana
			}
		});
		
		JLabel titulo = new JLabel("<html><body><br>UNIVERSIDAD CAT�LICA<br>BOLIVIANA 'SAN PABLO'<br><br></body></html>");
		titulo.setFont(new Font("Verdana", Font.BOLD, 22));
		JLabel nombre = new JLabel("Univ. Mabel Aguilera");
		nombre.setFont(new Font("Verdana", Font.PLAIN, 20));
		JLabel espacio = new JLabel("<html><body><br>&nbsp;</body></html>");
		espacio.setFont(new Font("Verdana", Font.BOLD, 20));		
		JLabel nomSistema = new JLabel(" Sistema: CAJERO AUTOM�TICO ");
		nomSistema.setFont(new Font("Verdana", Font.BOLD, 20));
		
		inicio.add(titulo);
		inicio.add(nombre);
		inicio.add(nomSistema);
		inicio.add(espacio);
		inicio.add(btnIniciar);
		add(inicio);		
	}
}
