package proCajeroAutomatico;
public class Persona {

	// Atributos
	private String nombre;
	private String apellido;
	private String ci;
	
	// Constructor con Par�metros
	public Persona(String nombre, String apellido, String ci) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.ci = ci;
	}
	// M�todos
	public void mostrar(){
		System.out.print("Nombre: "+this.nombre+"\tApellido: "+this.apellido+"\tCI:: "+this.ci);
	}
	public String getNomCompleto() {
		return nombre+" "+apellido;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getCi() {
		return ci;
	}
	public void setCi(String ci) {
		this.ci = ci;
	}

	
	
	
}
