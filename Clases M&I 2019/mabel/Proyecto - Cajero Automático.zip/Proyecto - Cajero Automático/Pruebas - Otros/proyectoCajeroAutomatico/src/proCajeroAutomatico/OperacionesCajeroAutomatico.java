package proCajeroAutomatico;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SpringLayout.Constraints;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class OperacionesCajeroAutomatico extends JFrame {
	private BorderLayout contentPane;
	private JPanel menu;
	private JButton saldo;
	private JButton retiro;
	private JButton deposito;
	private JButton transferencia;
	private JButton ver_transacciones;
	private JButton cambiar_contrasena;
	private JButton salir;

	public OperacionesCajeroAutomatico(final Cuenta c[], final int i, final int nroCuentas) {
		super("Cajero Autom�tico - Mabel Aguilera");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 200, 500, 400);
		contentPane = new BorderLayout();
		setResizable(false); // tama�o Fijo del Frame
		
		menu = new JPanel();
	    menu.setBackground(Color.ORANGE);
	    menu.setPreferredSize(new Dimension(450, 340));
	    
		JLabel msj = new JLabel("<html><body><br>ELIJA LA OPERACION A REALIZAR<br><br></body></html>");
		msj.setFont(new Font("Verdana", Font.BOLD, 22));
		
		saldo = new JButton("SALDO");
		saldo.setPreferredSize(new Dimension(180, 80));
		saldo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//c[i].mostrar();
				JOptionPane.showMessageDialog(null, "Nombre: "+c[i].getNomCompleto()+"\nCI: "+c[i].getCI()+"\nNro. de Cuenta: "+c[i].getNroCuenta()+"\nSaldo: "+c[i].getMonto()+" Bs.");
			}
		});
		retiro = new JButton("RETIRO");
		retiro.setPreferredSize(new Dimension(180, 80));
		retiro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double montoRetiro = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el monto a Retirar:"));
				if(montoRetiro > c[i].getMonto()) {
					JOptionPane.showMessageDialog(null, "No tiene saldo suficiente.", "Sin Saldo", 0);
				}else if(montoRetiro <= 0) {
					JOptionPane.showMessageDialog(null, "El retiro debe ser mayor a 0 Bs.");
				}else {
					Double mAnterior = c[i].getMonto();
					c[i].setMonto(c[i].getMonto()-montoRetiro);
					// actualizar la informacion en archivo.txt
					try {
						String reg = c[i].getNroCuenta()+"\t"+"RETIRO   "+"\t"+mAnterior+" Bs.\t"+montoRetiro+" Bs.\t"+c[i].getMonto()+" Bs.";
						registrarTransaccionEnArchivoBinario(reg);
						actualizarFichero(c, nroCuentas);
					} catch (FileNotFoundException e2) {
						System.out.println("Error" + e2.getMessage());
					}
					JOptionPane.showMessageDialog(null, "Retiro realizado satisfactoriamente.", "Operaci�n Realizada Con �xito", 1);
				}
			}
		});
		deposito = new JButton("DEPOSITO");
		deposito.setPreferredSize(new Dimension(180, 80));
		deposito.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double montoDeposito = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el monto a Depositar:"));
				Double mAnterior = c[i].getMonto();
				c[i].setMonto(c[i].getMonto()+montoDeposito);
				// actualizar la informacion en archivo.txt
				try {
					String reg = c[i].getNroCuenta()+"\t"+"DEPOSITO "+"\t"+mAnterior+" Bs.\t"+montoDeposito+" Bs.\t"+c[i].getMonto()+" Bs.";
					registrarTransaccionEnArchivoBinario(reg);
					actualizarFichero(c, nroCuentas);
				} catch (FileNotFoundException e2) {
					System.out.println("Error" + e2.getMessage());
				}
				JOptionPane.showMessageDialog(null, "Dep�sito realizado satisfactoriamente.");
				//ingresarSistema(txtNroCuenta.getText(), txtConstrasena.getText());
			}
		});
		transferencia = new JButton("TRANSFERENCIA");
		transferencia.setPreferredSize(new Dimension(180, 80));
		transferencia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nroCuentaDestino = JOptionPane.showInputDialog("Ingrese el n�mero de cuenta a la cual realizar� la Transferencia");
				boolean sw2 = true;
				for (int j = 0; j < nroCuentas; j++) {	
					if(nroCuentaDestino.equals(c[j].getNroCuenta())){
						sw2 = false;
						Double montoTranferencia = Double.parseDouble(JOptionPane.showInputDialog("Nro de Cuenta: "+c[j].getNroCuenta()+"\nNombre: "+c[j].getNombre()+" "+c[j].getApellido()+"\nCi.: "+c[j].getCi()+"\n\nIngrese el monto a Transferir: "));
						if(montoTranferencia > 0) {
							if(c[i].getMonto() >= montoTranferencia) {
								Double mAnterior = c[i].getMonto();
								Double mAnterior2 = c[j].getMonto();
								c[i].setMonto(c[i].getMonto() - montoTranferencia);
								c[j].setMonto(c[j].getMonto() + montoTranferencia);
								String reg = c[i].getNroCuenta()+"\t"+"OUT TRANSF"+"\t"+mAnterior+" Bs.\t"+montoTranferencia+"Bs. \t"+c[i].getMonto()+" Bs.\t"+nroCuentaDestino;
								registrarTransaccionEnArchivoBinario(reg);
								String reg2 = c[j].getNroCuenta()+"\t"+"IN TRANSF"+"\t"+mAnterior2+" Bs.\t"+montoTranferencia+"Bs. \t"+c[j].getMonto()+" Bs.\t"+c[i].getNroCuenta();
								registrarTransaccionEnArchivoBinario(reg2);
								JOptionPane.showMessageDialog(null, "Transferencia realizada exitosamente.", "Operaci�n Realizada Con �xito", 1);
							}else {
								JOptionPane.showMessageDialog(null, "No tiene saldo suficiente.", "Sin Saldo", 0);
							}
						}else {
							JOptionPane.showMessageDialog(null, "El monto de la transferencia debe ser mayor a 0 Bs.");
						}
					}
				}
				if(sw2) {
					JOptionPane.showMessageDialog(null, "El Nro de Cuenta ingresado no existe.", "Nro de Cuenta no Exixte", 0);
				}
				// actualizar la informacion en archivo.txt
				try {
					actualizarFichero(c, nroCuentas);
				} catch (FileNotFoundException e2) {
					System.out.println("Error" + e2.getMessage());
				}
			}
		});
		ver_transacciones = new JButton("TRANSACCIONES");
		ver_transacciones.setPreferredSize(new Dimension(140, 80));
		ver_transacciones.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String regs[] = leerRegistroTransaccionesArchivoBinario();
				String msj = "Nro Cuenta\tTipo Transc\tS. Inicial\tM. Transc\tSaldo\t\tNro Cuenta Transf<br>";
				for (int j = 0; j < regs.length; j++) {
					if(regs[j] != null){
						String ps[] = regs[j].split("\t"); // para mostrar solo las transacciones de la cuenta
						//System.out.println(ps[0]);
						if(ps[0].equals(c[i].getNroCuenta())) {
							msj += regs[j]+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>";	
						}
					}
				}
				//JOptionPane.showMessageDialog(null, msj);
				JOptionPane.showMessageDialog(null, "<html><pre>"+msj+"</pre></html>", "Transacciones", 1);
			}
		});

		cambiar_contrasena = new JButton("<html>&nbsp;&nbsp;&nbsp;&nbsp;CAMBIAR<br>CONTRASE�A</html>");
		cambiar_contrasena.setPreferredSize(new Dimension(135, 80));
		cambiar_contrasena.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String contrasenaAntigua 	= JOptionPane.showInputDialog("Ingrese su contrase�a Actual: ");
				if(contrasenaAntigua.equals(c[i].getContrasena())) {
					String contrasenaNueva 		= JOptionPane.showInputDialog("Ingrese su nueva contrase�a: ");
					c[i].setContrasena(contrasenaNueva);
					JOptionPane.showMessageDialog(null, "Constrase�a Actualizada Correctamente.");
				}else {
					JOptionPane.showMessageDialog(null, "Constrase�a Incorrecta.");	
				}
				// actualizar la informacion en archivo.txt
				try {
					actualizarFichero(c, nroCuentas);
				} catch (FileNotFoundException e2) {
					System.out.println("Error" + e2.getMessage());
				}			
			}
		});
		salir = new JButton("SALIR");
		salir.setPreferredSize(new Dimension(80, 80));
		salir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Gracias por su visita.");
				CajeroAutomatico login = new CajeroAutomatico(c, nroCuentas);
				dispose(); // CERRAR VENTANA
				login.setVisible(true); // hacer visible la ventana
			}
		});

		menu.add(msj);
		menu.add(saldo);
		menu.add(retiro);
		menu.add(deposito);
		menu.add(transferencia);
		menu.add(ver_transacciones);
		menu.add(cambiar_contrasena);
		menu.add(salir);
		add(menu);
	}
	void borrarFichero() throws FileNotFoundException {
		try {
			String data ="";
			FileOutputStream fout = new FileOutputStream("archivo.txt");
			byte cb[];
			cb = data.getBytes();
			fout.write(cb);
			fout.close();
			//System.out.println("el registro fue grabado exitosamente");
		}catch (Exception e1) {
			System.out.println("Error" + e1.getMessage());
		}
	}
	void actualizarFichero(Cuenta c[], int nroCuentas) throws FileNotFoundException {
		try {
			borrarFichero();
			FileOutputStream fout = new FileOutputStream("archivo.txt", true);
			for (int j = 0; j < nroCuentas; j++) {
				String data =c[j].getNombre()+"\t"+c[j].getApellido()+"\t"+c[j].getCi()+"\t"+c[j].getNroCuenta()+"\t"+c[j].getContrasena()+"\t"+c[j].getMonto()+"\n";
				byte cb[];
				cb = data.getBytes();
				fout.write(cb);
			}
			fout.close();
		}catch (Exception e1) {
			System.out.println("Error" + e1.getMessage());
		}
	}
	public void registrarTransaccionEnArchivoBinario(String registro) {
		
		FileOutputStream fos = null;
        DataOutputStream salida = null;
        try {
        	String reg[] = leerRegistroTransaccionesArchivoBinario();
            fos = new FileOutputStream("archivoBinario.dat");
            salida = new DataOutputStream(fos);
            for (int i = 0; i < reg.length; i++) {
            	if(reg[i] != null) {
            		//System.out.println(reg[i]);
                	salida.writeUTF(reg[i]);	
            	}
            	
			}
            salida.writeUTF(registro);
            fos.close();
            salida.close();
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (EOFException e) {
            System.out.println("Fin de fichero");
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
	}
	public String[] leerRegistroTransaccionesArchivoBinario() {
        FileInputStream fis = null;
        DataInputStream entrada = null;
        String n[] = new String[100];
        try {
            fis = new FileInputStream("archivoBinario.dat");
            entrada = new DataInputStream(fis);
            int i = 0;
            while (true) {   
            	n[i] = entrada.readUTF();
            	//n = entrada.readInt();  //se lee  un entero del fichero
                //System.out.println(n[i]);  //se muestra en pantalla
                i++;
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (EOFException e) {
            //System.out.println("Fin de fichero");
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return n;
	}
}
