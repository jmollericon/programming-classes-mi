package proCajeroAutomatico;
	
public class Transaccion {
	private String nroCuenta;
	private String tipo;
	private Double monto;

	public Transaccion(String nroCuenta, String tipo, Double monto) {
		this.nroCuenta = nroCuenta;
		this.tipo = tipo;
		this.monto = monto;
	}

	public String getNroCuenta() {
		return nroCuenta;
	}

	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public Double getMonto() {
		return monto;
	}

	public void setMonto(Double monto) {
		this.monto = monto;
	}
	
	public void mostrar() {
		System.out.println("informaci�n: ");
		System.out.println(nroCuenta+"\t"+tipo+"\t"+monto);
	}
	
}
