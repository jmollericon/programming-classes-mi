
public class Cuenta extends Persona{
	// Atributos
	private String nroCuenta;
	private String contrasena;
	private double monto;

	// Constructor con Par�metros
	public Cuenta(String nombre, String apellido, String ci, String nroCuenta, String contrasena, double monto) {
		super(nombre, apellido, ci); // se envia los parametros a la clase padre
		this.nroCuenta = nroCuenta;
		this.contrasena = contrasena;
		this.monto = monto;
	}
	// Metodos
	public void mostrar(){
		super.mostrar();
		System.out.println("\tNroCuenta: "+this.nroCuenta+"\tContrase�a: "+this.contrasena+"\tMonto: "+this.monto);
	}
	public String getNroCuenta() {
		return nroCuenta;
	}
	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}
	public String getContrasena() {
		return contrasena;
	}
	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}
	public double getMonto() {
		return monto;
	}
	public void setMonto(double monto) {
		this.monto = monto;
	}
	public String getNomCompleto() {
		return super.getNomCompleto();
	}
	public String getCI() {
		return super.getCi();
	}
	public String getNombre() {
		return super.getNombre();
	}
	public String getApellido() {
		return super.getApellido();
	}
	
	
	
	
}
