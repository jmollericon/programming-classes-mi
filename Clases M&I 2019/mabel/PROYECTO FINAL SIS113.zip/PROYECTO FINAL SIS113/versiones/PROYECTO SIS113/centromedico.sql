/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 100138
 Source Host           : localhost:3306
 Source Schema         : centromedico

 Target Server Type    : MySQL
 Target Server Version : 100138
 File Encoding         : 65001

 Date: 14/12/2019 10:22:45
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for citasmedicas
-- ----------------------------
DROP TABLE IF EXISTS `citasmedicas`;
CREATE TABLE `citasmedicas`  (
  `ci` int(50) NULL DEFAULT NULL,
  `especialidad` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `doctor` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `fecha_hora` datetime(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of citasmedicas
-- ----------------------------
INSERT INTO `citasmedicas` VALUES (8897949, 'CIRUGIAS      ', 'DR. FAUSTINO VEGA QUISPE', '2019-12-31 14:00:00');
INSERT INTO `citasmedicas` VALUES (6754632, 'MEDICINA GENERAL', 'DR. LUISA MARTINEZ LUNA', '2019-12-30 08:35:20');

-- ----------------------------
-- Table structure for doctores
-- ----------------------------
DROP TABLE IF EXISTS `doctores`;
CREATE TABLE `doctores`  (
  `ci` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `nombre` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ap_paterno` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ap_materno` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `especialidad` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for especialidades
-- ----------------------------
DROP TABLE IF EXISTS `especialidades`;
CREATE TABLE `especialidades`  (
  `id` int(11) NOT NULL,
  `especialidad` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for pacientes
-- ----------------------------
DROP TABLE IF EXISTS `pacientes`;
CREATE TABLE `pacientes`  (
  `ci` int(50) NOT NULL,
  `nombre` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `apellido_paterno` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `apellido_materno` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `fecha_nac` date NULL DEFAULT NULL,
  `cel` int(50) NULL DEFAULT NULL,
  `tipo_sangre` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `alergias` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `persona_referencia` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cel_referencia` int(100) NULL DEFAULT NULL,
  PRIMARY KEY (`ci`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of pacientes
-- ----------------------------
INSERT INTO `pacientes` VALUES (252525, 'juan', 'Perez', 'perez', '1990-01-25', 7252525, 'ooo', 'linh', 'jhsjhjjhg', 758585);
INSERT INTO `pacientes` VALUES (654874, 'iuyiuyi', 'iuyiy', 'iuyiyiy', '2019-01-12', 654645, 'jhgjgj', 'oiyuoi', 'iuyuiyiuyi', 456789);

-- ----------------------------
-- Table structure for usuarios
-- ----------------------------
DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios`  (
  `ci` int(50) NOT NULL,
  `ap_paterno` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ap_materno` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `nombres` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `nomUsuario` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `passUsuario` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `celular` int(50) NULL DEFAULT NULL,
  `rol` int(10) NULL DEFAULT NULL COMMENT '1: doctor, 2:secretaria, 3:gerente',
  PRIMARY KEY (`ci`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of usuarios
-- ----------------------------
INSERT INTO `usuarios` VALUES (111, 'perez', 'fernandez', 'juan', 'doctor', 'doctor', 123, 1);
INSERT INTO `usuarios` VALUES (222, 'soria', 'torrico', 'marcela', 'secretaria', 'secretaria', 332, 2);
INSERT INTO `usuarios` VALUES (333, 'camacho', 'pumari', 'lucas', 'gerente', 'gerente', 456, 3);

SET FOREIGN_KEY_CHECKS = 1;
