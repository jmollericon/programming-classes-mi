package proSIS113;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;

import javax.swing.SwingConstants;
import javax.swing.JTextPane;

public class ListaCitasMedicas {

	private JFrame frame;
	
	private int nroCitasMedicas = 0;
	private CitaMedica[] cm;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListaCitasMedicas window = new ListaCitasMedicas();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ListaCitasMedicas() {
		int n = 100; // capacidad en n�mero de cuentas
    	cm = new CitaMedica[n];
    	leerArchivoCitasMedicas(cm);
		initialize();
	}
	public void mostrarListaCitasMedicas(){
		this.frame.setVisible(true); // mostrar ventana
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(102, 205, 170));
		frame.setBounds(350, 180, 600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblControlParaCentro = new JLabel("LISTA DE PACIENTES REGISTRADOS");
		lblControlParaCentro.setHorizontalAlignment(SwingConstants.CENTER);
		lblControlParaCentro.setForeground(new Color(0, 128, 128));
		lblControlParaCentro.setFont(new Font("Verdana", Font.BOLD, 20));
		lblControlParaCentro.setBounds(0, 0, 584, 47);
		frame.getContentPane().add(lblControlParaCentro);
		
		JButton btnNewButton = new JButton("ATRAS");
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MenuSecretaria mp = new MenuSecretaria();
				mp.mostrarMenuSecretaria();
				frame.setVisible(false); // cerramos la ventana Inicio
			}
		});
		btnNewButton.setBackground(new Color(0, 206, 209));
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 18));
		btnNewButton.setBounds(24, 290, 113, 47);
		frame.getContentPane().add(btnNewButton);
		
		JTextPane textPane = new JTextPane();
		textPane.setFont(new Font("Verdana", Font.PLAIN, 9));
		textPane.setBackground(new Color(224, 255, 255));
		textPane.setEditable(false);
		textPane.setBounds(10, 41, 564, 237);
		frame.getContentPane().add(textPane);

    	String lista = " #    DATOS PACIENTE\t\tATENCI�N EN:\t\tFECHA.\n";
    		  lista += " =    ==================\t============ \t\t========\n";
    	for (int i=0; i<nroCitasMedicas; i++) {
    		//System.out.println(p[i].getApPaterno()+"\t"+p[i].getApMaterno()+"\t"+p[i].getNombres());
    		//lista += " "+(i+1)+"  "+cm[i].getCiPaciente()+"\t"+cm[i].getNomPaciente()+" "+cm[i].getespecialidad()+" "+cm[i].getespecialista()+"\t"+cm[i].getfecha()+" "+cm[i].gethora()+"\n";
    		lista += " "+(i+1)+":  "+cm[i].getCiPaciente()+"\t\t\t"+cm[i].getespecialidad()+" "+"\t\t"+cm[i].getfecha()+"\n";
    		lista += "     "+cm[i].getNomPaciente()+"\t"+cm[i].getespecialista()+"\t"+cm[i].gethora()+"\n";
    	}
		textPane.setText(lista);
	}
	// Metodos acceso a archivos
	void leerArchivoCitasMedicas(CitaMedica cm[]){
		try {
            File archivo = new File ("citasmedicas.txt");
            FileReader fr = new FileReader (archivo);
            BufferedReader br = new BufferedReader(fr);

            String linea;
            String[] parts = null;
            while((linea = br.readLine()) != null) {
            	parts = linea.split(";"); 
            	/* CI 			= parts[0];
            	 * NOMPACIENTE	= parts[1];
            	 * ESPECIALIDAD = parts[2];
            	 * ESPECIALISTA	= parts[3];
            	 * FECHA  		= parts[4];
            	 * HORA			= parts[5]; */
            	this.cm[nroCitasMedicas] = new CitaMedica(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5]);
            	nroCitasMedicas++;
            }
            fr.close();
        }
        catch(Exception e) {
            System.out.println("Excepcion leyendo fichero: " + e);
        }		
	}
	void actualizarFichero(CitaMedica cm[], int nroCitasMedicas) throws FileNotFoundException {
		try {
			borrarFichero();
			FileOutputStream fout = new FileOutputStream("citasmedicas.txt", true);
			for (int j = 0; j < nroCitasMedicas; j++) {
				String data = cm[j].getCiPaciente()+";"+cm[j].getNomPaciente()+";"+cm[j].getespecialidad()+";"+cm[j].getespecialista()+";"+cm[j].getfecha()+";"+cm[j].gethora()+"\n";
				byte cb[];
				cb = data.getBytes();
				fout.write(cb);
			}
			fout.close();
		}catch (Exception e1) {
			System.out.println("Error" + e1.getMessage());
		}
	}
	void borrarFichero() throws FileNotFoundException {
		try {
			String data ="";
			FileOutputStream fout = new FileOutputStream("citasmedicas.txt");
			byte cb[];
			cb = data.getBytes();
			fout.write(cb);
			fout.close();
			//System.out.println("el registro fue grabado exitosamente");
		}catch (Exception e1) {
			System.out.println("Error" + e1.getMessage());
		}
	}
}
