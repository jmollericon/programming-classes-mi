package proSIS113;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.SwingConstants;
import javax.swing.JTextField;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

public class RegistrarPaciente {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_11;

	private int nroPacientes = 0;
	private Paciente[] p;
	
	Conexion con = new Conexion();
	Connection cn = null;
	Statement stm = null;
	ResultSet rs = null;
	PreparedStatement stmt;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistrarPaciente window = new RegistrarPaciente();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RegistrarPaciente() {
		int n = 100; // capacidad en n�mero de cuentas
    	p = new Paciente[n];
    	leerArchivoPacientes(p);
		initialize();
	}
	public void mostrarRegistrarPaciente(){
		this.frame.setVisible(true); // mostrar ventana
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Verdana", Font.PLAIN, 14));
		frame.getContentPane().setBackground(new Color(102, 205, 170));
		frame.setBounds(350, 180, 600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblControlParaCentro = new JLabel("REGISTRAR NUEVO PACIENTE");
		lblControlParaCentro.setHorizontalAlignment(SwingConstants.CENTER);
		lblControlParaCentro.setForeground(Color.GREEN);
		lblControlParaCentro.setFont(new Font("Verdana", Font.BOLD, 20));
		lblControlParaCentro.setBounds(0, 5, 584, 47);
		frame.getContentPane().add(lblControlParaCentro);
		
		JButton btnNewButton = new JButton("ATRAS");
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MenuSecretaria mp = new MenuSecretaria();
				mp.mostrarMenuSecretaria();
				frame.setVisible(false); // cerramos la ventana Inicio
			}
		});
		btnNewButton.setBackground(new Color(0, 206, 209));
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 18));
		btnNewButton.setBounds(24, 290, 113, 47);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnGuardar = new JButton("GUARDAR");
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String apPat, apMat, nom, feNac, tSangre, alergias, nomRef;
				int ci, cel, celRef;
				
				ci    	= Integer.parseInt(textField_7.getText());
				nom   	= textField_1.getText();
				apPat 	= textField.getText();
				apMat 	= textField_6.getText();
				
				feNac 	= textField_2.getText();

				cel   		= Integer.parseInt(textField_8.getText());
				tSangre 	= textField_3.getText();
				alergias 	= textField_9.getText();  
				nomRef   	= textField_5.getText();
				celRef   	= Integer.parseInt(textField_11.getText());

				registrarDatosPaciente(ci, nom, apPat, apMat, feNac, cel, tSangre, alergias, nomRef, celRef);
				
				
				
				// Creamos el objeto 'Paciente'
				//p[nroPacientes] = new Paciente(ci, apPat, apMat, nom, feNac, cel, tSangre, alergias, nomRef, celRef);
				nroPacientes++;
				System.out.println(ci+ apPat+ apMat+nom+ feNac+ cel+ tSangre+ alergias+ nomRef+ celRef);

				// actualizar la informacion en archivo.txt
				try {
					actualizarFichero(p, nroPacientes);
				} catch (FileNotFoundException e2) {
					System.out.println("Error" + e2.getMessage());
				}
				JOptionPane.showMessageDialog(null, "Registro realizado satisfactoriamente.", "Operaci�n Realizada Con �xito", 1);
				
				// limpiamos los campos llenados
				textField.setText("");
				textField_6.setText("");
				textField_1.setText("");
				textField_7.setText("");
				textField_2.setText("");
				textField_8.setText("");
				textField_3.setText("");
				textField_9.setText("");  
				textField_5.setText("");
				textField_11.setText("");
			
			}
		});
		btnGuardar.setForeground(Color.BLUE);
		btnGuardar.setFont(new Font("Verdana", Font.BOLD, 18));
		btnGuardar.setBackground(new Color(0, 206, 209));
		btnGuardar.setBounds(390, 290, 161, 47);
		frame.getContentPane().add(btnGuardar);
		
		JButton btnLimpiar = new JButton("LIMPIAR");
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText("");
				textField_6.setText("");
				textField_1.setText("");
				textField_7.setText("");
				textField_2.setText("");
				textField_8.setText("");
				textField_3.setText("");
				textField_9.setText("");  
				textField_5.setText("");
				textField_11.setText("");
			}
		});
		btnLimpiar.setForeground(Color.BLUE);
		btnLimpiar.setFont(new Font("Verdana", Font.BOLD, 18));
		btnLimpiar.setBackground(new Color(0, 206, 209));
		btnLimpiar.setBounds(200, 290, 133, 47);
		frame.getContentPane().add(btnLimpiar);
		
		textField = new JTextField();
		textField.setFont(new Font("Verdana", Font.PLAIN, 14));
		textField.setBounds(136, 63, 140, 28);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNombresYApellidos = new JLabel("Ap. Paterno:");
		lblNombresYApellidos.setFont(new Font("Verdana", Font.BOLD, 14));
		lblNombresYApellidos.setBounds(10, 58, 116, 35);
		frame.getContentPane().add(lblNombresYApellidos);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Verdana", Font.PLAIN, 14));
		textField_1.setColumns(10);
		textField_1.setBounds(136, 107, 140, 28);
		frame.getContentPane().add(textField_1);
		
		JLabel lblNombres = new JLabel("Nombres:");
		lblNombres.setFont(new Font("Verdana", Font.BOLD, 14));
		lblNombres.setBounds(11, 104, 116, 35);
		frame.getContentPane().add(lblNombres);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Verdana", Font.PLAIN, 14));
		textField_2.setColumns(10);
		textField_2.setBounds(137, 152, 140, 28);
		frame.getContentPane().add(textField_2);
		
		JLabel lblFechaNac = new JLabel("Fecha Nac.:");
		lblFechaNac.setFont(new Font("Verdana", Font.BOLD, 14));
		lblFechaNac.setBounds(10, 149, 116, 35);
		frame.getContentPane().add(lblFechaNac);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Verdana", Font.PLAIN, 14));
		textField_3.setColumns(10);
		textField_3.setBounds(136, 198, 140, 28);
		frame.getContentPane().add(textField_3);
		
		JLabel lblTipoDeSangre = new JLabel("Tipo Sangre:");
		lblTipoDeSangre.setFont(new Font("Verdana", Font.BOLD, 14));
		lblTipoDeSangre.setBounds(10, 193, 116, 35);
		frame.getContentPane().add(lblTipoDeSangre);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Verdana", Font.PLAIN, 14));
		textField_5.setColumns(10);
		textField_5.setBounds(137, 244, 140, 28);
		frame.getContentPane().add(textField_5);
		
		JLabel lblPesonaRef = new JLabel("Pesona Ref.:");
		lblPesonaRef.setFont(new Font("Verdana", Font.BOLD, 14));
		lblPesonaRef.setBounds(11, 239, 116, 35);
		frame.getContentPane().add(lblPesonaRef);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Verdana", Font.PLAIN, 14));
		textField_6.setColumns(10);
		textField_6.setBounds(413, 63, 161, 28);
		frame.getContentPane().add(textField_6);
		
		JLabel lblApMaterno = new JLabel("Ap. Materno:");
		lblApMaterno.setFont(new Font("Verdana", Font.BOLD, 14));
		lblApMaterno.setBounds(287, 58, 116, 35);
		frame.getContentPane().add(lblApMaterno);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Verdana", Font.PLAIN, 14));
		textField_7.setColumns(10);
		textField_7.setBounds(413, 107, 161, 28);
		frame.getContentPane().add(textField_7);
		
		JLabel lblCi = new JLabel("CI:");
		lblCi.setFont(new Font("Verdana", Font.BOLD, 14));
		lblCi.setBounds(287, 102, 116, 35);
		frame.getContentPane().add(lblCi);
		
		textField_8 = new JTextField();
		textField_8.setFont(new Font("Verdana", Font.PLAIN, 14));
		textField_8.setColumns(10);
		textField_8.setBounds(412, 152, 161, 28);
		frame.getContentPane().add(textField_8);
		
		JLabel lblNroCelular = new JLabel("Nro. Celular:");
		lblNroCelular.setFont(new Font("Verdana", Font.BOLD, 14));
		lblNroCelular.setBounds(286, 147, 116, 35);
		frame.getContentPane().add(lblNroCelular);
		
		textField_9 = new JTextField();
		textField_9.setFont(new Font("Verdana", Font.PLAIN, 14));
		textField_9.setColumns(10);
		textField_9.setBounds(412, 196, 161, 28);
		frame.getContentPane().add(textField_9);
		
		JLabel lblAlergias = new JLabel("Alergias:");
		lblAlergias.setFont(new Font("Verdana", Font.BOLD, 14));
		lblAlergias.setBounds(286, 191, 116, 35);
		frame.getContentPane().add(lblAlergias);
		
		textField_11 = new JTextField();
		textField_11.setFont(new Font("Verdana", Font.PLAIN, 14));
		textField_11.setColumns(10);
		textField_11.setBounds(413, 242, 161, 28);
		frame.getContentPane().add(textField_11);
		
		JLabel lblNroCelRef = new JLabel("Nro. Cel. Ref.:");
		lblNroCelRef.setFont(new Font("Verdana", Font.BOLD, 14));
		lblNroCelRef.setBounds(287, 237, 116, 35);
		frame.getContentPane().add(lblNroCelRef);
	}
	
	// Metodos acceso a archivos
	void leerArchivoPacientes(Paciente p[]){
		try {
            File archivo = new File ("pacientes.txt");
            FileReader fr = new FileReader (archivo);
            BufferedReader br = new BufferedReader(fr);

            String linea;
            String[] parts = null;
            while((linea = br.readLine()) != null) {
            	parts = linea.split(";"); 
            	/* CI 			= parts[0];
            	 * AP PAT 		= parts[1];
            	 * AP MAT 		= parts[2];
            	 * NOMBRES 		= parts[3];
            	 * FECHA NAC 	= parts[4];
            	 * CELULAR		= parts[5];
            	 * TIPO SANGRE  = parts[6];
            	 * ALERGIAS		= parts[7];
            	 * PER REF		= parts[8];
            	 * CEL REF		= parts[9]; */
            	this.p[nroPacientes] = new Paciente(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6], parts[7], parts[8], parts[9]);
            	nroPacientes++;
            }
            fr.close();
        }
        catch(Exception e) {
            System.out.println("Excepcion leyendo fichero: " + e);
        }		
	}
	void actualizarFichero(Paciente p[], int nroCuentas) throws FileNotFoundException {
		try {
			borrarFichero();
			FileOutputStream fout = new FileOutputStream("pacientes.txt", true);
			for (int j = 0; j < nroCuentas; j++) {
				String data = p[j].getCi()+";"+p[j].getApPaterno()+";"+p[j].getApMaterno()+";"+p[j].getNombres()+";"+p[j].getFechaNac()+";"+p[j].getCelular()+";"+p[j].getTipoSangre()+";"+p[j].getAlergias()+";"+p[j].getNomRef()+";"+p[j].getCelRef()+"\n";
				byte cb[];
				cb = data.getBytes();
				fout.write(cb);
			}
			fout.close();
		}catch (Exception e1) {
			System.out.println("Error" + e1.getMessage());
		}
	}
	void borrarFichero() throws FileNotFoundException {
		try {
			String data = "";
			FileOutputStream fout = new FileOutputStream("pacientes.txt");
			byte cb[];
			cb = data.getBytes();
			fout.write(cb);
			fout.close();
			//System.out.println("el registro fue grabado exitosamente");
		}catch (Exception e1) {
			System.out.println("Error" + e1.getMessage());
		}
	}
	
	
	
	void registrarDatosPaciente(int ci, String nombre, String apPaterno, String apMaterno, String fechaNac, int celular, String tSangre, String alergias, String nomRef, int celRef){
		/*Calendar cal = Calendar.getInstance();
	    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	    String strDate = sdf.format(cal.getTime());*/
	    //System.out.println(strDate);
		try {
			cn = con.getConexionMYSQL();
			stmt = (PreparedStatement) cn.prepareStatement("INSERT INTO pacientes " + "VALUES ("+ci+", '"+nombre+"', '"+apPaterno+"', '"+apMaterno+"', '"+fechaNac+"', "+celular+" ,'"+tSangre+"', '"+alergias+"', '"+nomRef+"', "+celRef+")");
			int retorno = stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			try {
				if(rs != null) rs.close();
				if(stm != null) stm.close();
				if(cn != null) cn.close();
				
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}
}
