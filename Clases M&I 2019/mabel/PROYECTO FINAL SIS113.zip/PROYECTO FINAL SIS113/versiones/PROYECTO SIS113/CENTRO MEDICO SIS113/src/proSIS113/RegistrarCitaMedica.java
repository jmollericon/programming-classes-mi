package proSIS113;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

public class RegistrarCitaMedica {

	private JFrame frame;
	private JTextField textField_3;
	private JTextField textField_9;

	private JComboBox comboBox;
	private JComboBox comboBox_1;
	private JComboBox comboBox_2;
	
	private int nroCitasMedicas = 0;
	private CitaMedica[] cm;

	private int nroPacientes = 0;
	private Paciente[] p;
	
	Conexion con = new Conexion();
	Connection cn = null;
	Statement stm = null;
	ResultSet rs = null;
	PreparedStatement stmt;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistrarCitaMedica window = new RegistrarCitaMedica();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RegistrarCitaMedica() {
		int n = 100; // capacidad en n�mero de citas m�dicas
    	cm = new CitaMedica[n];
    	leerArchivoCitasMedicas(cm);
    	
    	n = 100; // capacidad en n�mero de pacientes
    	p = new Paciente[n];
    	leerArchivoPacientes(p);
    	
		initialize();
		
		cargarPacientes(p, nroPacientes);
	}
	public void mostrarRegistrarCitaMedica(){
		this.frame.setVisible(true); // mostrar ventana
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Verdana", Font.PLAIN, 14));
		frame.getContentPane().setBackground(new Color(102, 205, 170));
		frame.setBounds(350, 180, 600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblControlParaCentro = new JLabel("REGISTRAR CITA M\u00C9DICA");
		lblControlParaCentro.setHorizontalAlignment(SwingConstants.CENTER);
		lblControlParaCentro.setForeground(Color.GREEN);
		lblControlParaCentro.setFont(new Font("Verdana", Font.BOLD, 20));
		lblControlParaCentro.setBounds(0, 0, 584, 47);
		frame.getContentPane().add(lblControlParaCentro);
		
		JButton btnNewButton = new JButton("ATRAS");
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MenuSecretaria mp = new MenuSecretaria();
				mp.mostrarMenuSecretaria();
				frame.setVisible(false); // cerramos la ventana Inicio
			}
		});
		btnNewButton.setBackground(new Color(0, 206, 209));
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 18));
		btnNewButton.setBounds(24, 290, 113, 47);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnGuardar = new JButton("GUARDAR");
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String ciNombre, especialidad, especialista, fecha, hora, nomPaciente;
				ciNombre 	 = (String)comboBox_2.getSelectedItem();
				especialidad = (String)comboBox.getSelectedItem();
				especialista = (String)comboBox_1.getSelectedItem();
				fecha		 = textField_3.getText();
				hora         = textField_9.getText();
				
				String[] m = null;
				m = ciNombre.split(":");
				int ciPaciente 	= Integer.parseInt(m[0]);
				nomPaciente = m[1];
				
				
				registrarCitaMedicaBD(ciPaciente, especialidad, especialista, fecha, hora);
				
				
				
				
				// Creamos el objeto 'CitaMedica'
				//cm[nroCitasMedicas] = new CitaMedica(ciPaciente, nomPaciente, especialidad, especialista, fecha, hora);
				nroCitasMedicas++;
				System.out.println(especialidad+ especialista+ fecha+ hora);
				
				// actualizar la informacion en archivo citasmedicas.txt
				try {
					//String reg = p[nroPacientes].getNroCuenta()+"\t"+"RETIRO   "+"\t"+mAnterior+" Bs.\t"+montoRetiro+" Bs.\t"+c[i].getMonto()+" Bs.";
					//registrarTransaccionEnArchivoBinario(reg);
					actualizarFichero(cm, nroCitasMedicas);
				} catch (FileNotFoundException e2) {
					System.out.println("Error" + e2.getMessage());
				}
				JOptionPane.showMessageDialog(null, "Registro realizado satisfactoriamente.", "Operaci�n Realizada Con �xito", 1);
				
				// limpiamos los campos llenados
				comboBox.setSelectedItem("SELECCIONAR");
				comboBox_1.setSelectedItem("SELECCIONAR");
				comboBox_2.setSelectedItem("SELECCIONAR");
				textField_3.setText("");
				textField_9.setText("");
			}
		});
		btnGuardar.setForeground(Color.BLUE);
		btnGuardar.setFont(new Font("Verdana", Font.BOLD, 18));
		btnGuardar.setBackground(new Color(0, 206, 209));
		btnGuardar.setBounds(390, 290, 161, 47);
		frame.getContentPane().add(btnGuardar);
		
		JButton btnLimpiar = new JButton("LIMPIAR");
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				comboBox.setSelectedItem("SELECCIONAR");
				comboBox_1.setSelectedItem("SELECCIONAR");
				comboBox_2.setSelectedItem("SELECCIONAR");
				textField_3.setText("");
				textField_9.setText("");
			}
		});
		btnLimpiar.setForeground(Color.BLUE);
		btnLimpiar.setFont(new Font("Verdana", Font.BOLD, 18));
		btnLimpiar.setBackground(new Color(0, 206, 209));
		btnLimpiar.setBounds(200, 290, 133, 47);
		frame.getContentPane().add(btnLimpiar);
		
		JLabel lblNombresYApellidos = new JLabel("Seleccionar Especialidad:");
		lblNombresYApellidos.setFont(new Font("Verdana", Font.BOLD, 14));
		lblNombresYApellidos.setBounds(53, 91, 208, 35);
		frame.getContentPane().add(lblNombresYApellidos);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Verdana", Font.PLAIN, 14));
		textField_3.setColumns(10);
		textField_3.setBounds(137, 194, 140, 28);
		frame.getContentPane().add(textField_3);
		
		JLabel lblTipoDeSangre = new JLabel("Fecha(d/m/a):");
		lblTipoDeSangre.setFont(new Font("Verdana", Font.BOLD, 14));
		lblTipoDeSangre.setBounds(10, 191, 127, 35);
		frame.getContentPane().add(lblTipoDeSangre);
		
		textField_9 = new JTextField();
		textField_9.setFont(new Font("Verdana", Font.PLAIN, 14));
		textField_9.setColumns(10);
		textField_9.setBounds(413, 194, 161, 28);
		frame.getContentPane().add(textField_9);
		
		JLabel lblAlergias = new JLabel("Hora(h:m):");
		lblAlergias.setFont(new Font("Verdana", Font.BOLD, 14));
		lblAlergias.setBounds(287, 191, 116, 35);
		frame.getContentPane().add(lblAlergias);
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"SELECCIONAR", "MEDICINA GENERAL", "CIRUGIAS      ", "ODONTOLOG\u00CDA", "PEDIATRIA", "OFTALMOLOGIA"}));
		comboBox.setFont(new Font("Verdana", Font.PLAIN, 12));
		comboBox.setToolTipText("");
		comboBox.setBounds(271, 95, 238, 28);
		frame.getContentPane().add(comboBox);
		
		JLabel lblSeleccionarEspecialista = new JLabel("Seleccionar Especialista:");
		lblSeleccionarEspecialista.setFont(new Font("Verdana", Font.BOLD, 14));
		lblSeleccionarEspecialista.setBounds(53, 130, 208, 35);
		frame.getContentPane().add(lblSeleccionarEspecialista);
		
		comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"SELECCIONAR", "DR. CARLOS ALAMEDA SANCHEZ", "DR. FAUSTINO VEGA QUISPE", "DR. MARIA ESCALERA RAMOS", "DR. CARLA PEREIRA MORALES", "DR. LUISA MARTINEZ LUNA"}));
		comboBox_1.setToolTipText("MEDICINA GENERAL\r\nCIRUGIAS");
		comboBox_1.setFont(new Font("Verdana", Font.PLAIN, 12));
		comboBox_1.setBounds(271, 134, 238, 28);
		frame.getContentPane().add(comboBox_1);
		
		JLabel lblSeleccionarPaciente = new JLabel("Seleccionar Paciente:");
		lblSeleccionarPaciente.setForeground(new Color(0, 0, 0));
		lblSeleccionarPaciente.setFont(new Font("Verdana", Font.BOLD, 14));
		lblSeleccionarPaciente.setBounds(53, 42, 208, 35);
		frame.getContentPane().add(lblSeleccionarPaciente);
		
		comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"SELECCIONAR"}));
		comboBox_2.setToolTipText("");
		comboBox_2.setFont(new Font("Verdana", Font.PLAIN, 12));
		comboBox_2.setBounds(236, 46, 307, 28);
		frame.getContentPane().add(comboBox_2);
	}
	// Metodos acceso a archivos
	void leerArchivoCitasMedicas(CitaMedica cm[]){
		try {
            File archivo = new File ("citasmedicas.txt");
            FileReader fr = new FileReader (archivo);
            BufferedReader br = new BufferedReader(fr);

            String linea;
            String[] parts = null;
            while((linea = br.readLine()) != null) {
            	parts = linea.split(";"); 
            	/* CI 			= parts[0];
            	 * NOMPACIENTE	= parts[1];
            	 * ESPECIALIDAD = parts[2];
            	 * ESPECIALISTA	= parts[3];
            	 * FECHA  		= parts[4];
            	 * HORA			= parts[5]; */
            	this.cm[nroCitasMedicas] = new CitaMedica(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5]);
            	nroCitasMedicas++;
            }
            fr.close();
        }
        catch(Exception e) {
            System.out.println("Excepcion leyendo fichero: " + e);
        }		
	}
	void actualizarFichero(CitaMedica cm[], int nroCitasMedicas) throws FileNotFoundException {
		try {
			borrarFichero();
			FileOutputStream fout = new FileOutputStream("citasmedicas.txt", true);
			for (int j = 0; j < nroCitasMedicas; j++) {
				String data = cm[j].getCiPaciente()+";"+cm[j].getNomPaciente()+";"+cm[j].getespecialidad()+";"+cm[j].getespecialista()+";"+cm[j].getfecha()+";"+cm[j].gethora()+"\n";
				byte cb[];
				cb = data.getBytes();
				fout.write(cb);
			}
			fout.close();
		}catch (Exception e1) {
			System.out.println("Error" + e1.getMessage());
		}
	}
	void borrarFichero() throws FileNotFoundException {
		try {
			String data ="";
			FileOutputStream fout = new FileOutputStream("citasmedicas.txt");
			byte cb[];
			cb = data.getBytes();
			fout.write(cb);
			fout.close();
			//System.out.println("el registro fue grabado exitosamente");
		}catch (Exception e1) {
			System.out.println("Error" + e1.getMessage());
		}
	}
	
	void leerArchivoPacientes(Paciente p[]){
		try {
            File archivo = new File ("pacientes.txt");
            FileReader fr = new FileReader (archivo);
            BufferedReader br = new BufferedReader(fr);

            String linea;
            String[] parts = null;
            while((linea = br.readLine()) != null) {
            	parts = linea.split(";"); 
            	/* CI 			= parts[0];
            	 * AP PAT 		= parts[1];
            	 * AP MAT 		= parts[2];
            	 * NOMBRES 		= parts[3];
            	 * FECHA NAC 	= parts[4];
            	 * CELULAR		= parts[5];
            	 * TIPO SANGRE  = parts[6];
            	 * ALERGIAS		= parts[7];
            	 * PER REF		= parts[8];
            	 * CEL REF		= parts[9]; */
            	this.p[nroPacientes] = new Paciente(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6], parts[7], parts[8], parts[9]);
            	nroPacientes++;
            }
            fr.close();
        }
        catch(Exception e) {
            System.out.println("Excepcion leyendo fichero pacientes: " + e);
        }		
	}
	
	void cargarPacientes(Paciente p[], int nroPacientes){
		System.out.println("nroAPcientes "+nroPacientes);
		String nomPac = "";
		for(int i=0;  i< nroPacientes; i++){
			nomPac = p[i].getCi()+": "+p[i].getApPaterno()+" "+p[i].getApMaterno()+" "+p[i].getNombres();
			//System.out.println("-> "+nomPac);
			comboBox_2.addItem(nomPac);
		}
	}
	void registrarCitaMedicaBD(int ci, String especialidad, String especialista, String fecha, String hora){
		/*Calendar cal = Calendar.getInstance();
	    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	    String strDate = sdf.format(cal.getTime());*/
	    //System.out.println(strDate);
		try {
			cn = con.getConexionMYSQL();
			stmt = (PreparedStatement) cn.prepareStatement("INSERT INTO citasmedicas " + "VALUES ("+ci+", '"+especialidad+"', '"+especialista+"', '"+fecha+" "+hora+"')");
			int retorno = stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			try {
				if(rs != null) rs.close();
				if(stm != null) stm.close();
				if(cn != null) cn.close();
				
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}
	
	
}
