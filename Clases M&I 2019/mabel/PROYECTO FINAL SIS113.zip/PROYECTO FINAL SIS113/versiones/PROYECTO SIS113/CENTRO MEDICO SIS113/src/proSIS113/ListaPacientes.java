package proSIS113;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;

import javax.swing.SwingConstants;
import javax.swing.JFormattedTextField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JTextPane;

public class ListaPacientes {

	private JFrame frame;

	private int nroPacientes = 0;
	private Paciente[] p;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListaPacientes window = new ListaPacientes();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ListaPacientes() {
		int n = 100; // capacidad en n�mero de cuentas
    	p = new Paciente[n];
    	leerArchivoPacientes(p);
		initialize();
	}
	public void mostrarListaPacientes(){
		this.frame.setVisible(true); // mostrar ventana
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(102, 205, 170));
		frame.setBounds(350, 180, 600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblControlParaCentro = new JLabel("LISTA DE PACIENTES REGISTRADOS");
		lblControlParaCentro.setHorizontalAlignment(SwingConstants.CENTER);
		lblControlParaCentro.setForeground(Color.GREEN);
		lblControlParaCentro.setFont(new Font("Verdana", Font.BOLD, 20));
		lblControlParaCentro.setBounds(0, 0, 584, 47);
		frame.getContentPane().add(lblControlParaCentro);
		
		JButton btnNewButton = new JButton("ATRAS");
		btnNewButton.setForeground(new Color(51, 51, 204));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MenuSecretaria mp = new MenuSecretaria();
				mp.mostrarMenuSecretaria();
				frame.setVisible(false); // cerramos la ventana Inicio
			}
		});
		btnNewButton.setBackground(new Color(0, 206, 209));
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 18));
		btnNewButton.setBounds(10, 303, 113, 47);
		frame.getContentPane().add(btnNewButton);
		
		JTextPane textPane = new JTextPane();
		textPane.setBackground(new Color(224, 255, 255));
		textPane.setFont(new Font("Verdana", Font.PLAIN, 11));
		textPane.setEditable(false);
		textPane.setBounds(10, 44, 564, 248);
		frame.getContentPane().add(textPane);
		
    	String lista = " #   DATOS PACIENTE\t\tFECHA NAC.    PERSONA REF.\tOTROS DATOS\n";
    		  lista += " =   ================\t========    ==========\t========\n";
    	for (int i = 0; i < nroPacientes; i++) {
    		//System.out.println(p[i].getApPaterno()+"\t"+p[i].getApMaterno()+"\t"+p[i].getNombres());
    		//lista += " "+(i+1)+"  "+p[i].getCi()+"\t"+p[i].getApPaterno()+" "+p[i].getApMaterno()+" "+p[i].getNombres()+"\t"+p[i].getFechaNac()+"   "+p[i].getCelular()+"   "+p[i].getCelRef()+"\n";
    		lista += " "+(i+1)+":  CI: "+p[i].getCi()+" - "+p[i].getApPaterno()+"\t"+p[i].getFechaNac()+"\t    "+p[i].getNomRef()+"\t"+p[i].getTipoSangre()+" (tipo sangre)\n";
    		lista += "      "+p[i].getApMaterno()+' '+p[i].getNombres()+"       \t"+p[i].getCelular()+"\t    Cel: "+p[i].getCelRef()+"\t"+p[i].getAlergias()+" (alergia)\n";
    	}
		textPane.setText(lista);
		
	}

	// Metodos acceso a archivos
	void leerArchivoPacientes(Paciente p[]){
		try {
            File archivo = new File ("pacientes.txt");
            FileReader fr = new FileReader (archivo);
            BufferedReader br = new BufferedReader(fr);

            String linea;
            String[] parts = null;
            while((linea = br.readLine()) != null) {
            	parts = linea.split(";"); 
            	/* CI 			= parts[0];
            	 * AP PAT 		= parts[1];
            	 * AP MAT 		= parts[2];
            	 * NOMBRES 		= parts[3];
            	 * FECHA NAC 	= parts[4];
            	 * CELULAR		= parts[5];
            	 * TIPO SANGRE  = parts[6];
            	 * ALERGIAS		= parts[7];
            	 * PER REF		= parts[8];
            	 * CEL REF		= parts[9]; */
            	this.p[nroPacientes] = new Paciente(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6], parts[7], parts[8], parts[9]);
            	nroPacientes++;
            }
            fr.close();
        }
        catch(Exception e) {
            System.out.println("Excepcion leyendo fichero: " + e);
        }		
	}
	void actualizarFichero(Paciente p[], int nroCuentas) throws FileNotFoundException {
		try {
			borrarFichero();
			FileOutputStream fout = new FileOutputStream("pacientes.txt", true);
			for (int j = 0; j < nroCuentas; j++) {
				String data = p[j].getCi()+";"+p[j].getApPaterno()+";"+p[j].getApMaterno()+";"+p[j].getNombres()+";"+p[j].getFechaNac()+";"+p[j].getCelular()+";"+p[j].getTipoSangre()+";"+p[j].getAlergias()+";"+p[j].getNomRef()+";"+p[j].getCelRef()+"\n";
				byte cb[];
				cb = data.getBytes();
				fout.write(cb);
			}
			fout.close();
		}catch (Exception e1) {
			System.out.println("Error" + e1.getMessage());
		}
	}
	void borrarFichero() throws FileNotFoundException {
		try {
			String data ="";
			FileOutputStream fout = new FileOutputStream("pacientes.txt");
			byte cb[];
			cb = data.getBytes();
			fout.write(cb);
			fout.close();
			//System.out.println("el registro fue grabado exitosamente");
		}catch (Exception e1) {
			System.out.println("Error" + e1.getMessage());
		}
	}
}
