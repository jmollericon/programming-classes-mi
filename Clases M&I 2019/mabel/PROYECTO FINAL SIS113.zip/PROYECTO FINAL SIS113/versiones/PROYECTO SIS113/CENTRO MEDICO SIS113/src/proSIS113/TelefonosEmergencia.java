package proSIS113;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.SwingConstants;
import javax.swing.JEditorPane;

public class TelefonosEmergencia {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelefonosEmergencia window = new TelefonosEmergencia();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TelefonosEmergencia() {
		initialize();
	}
	public void mostrarTelefonosEmergencia(){
		this.frame.setVisible(true); // mostrar ventana
	}
	
	public void mostrarListaPacientes(){
		this.frame.setVisible(true); // mostrar ventana
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(102, 205, 170));
		frame.setBounds(350, 180, 600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblControlParaCentro = new JLabel("LISTA DE PACIENTES REGISTRADOS");
		lblControlParaCentro.setHorizontalAlignment(SwingConstants.CENTER);
		lblControlParaCentro.setForeground(Color.GREEN);
		lblControlParaCentro.setFont(new Font("Verdana", Font.BOLD, 20));
		lblControlParaCentro.setBounds(0, 0, 584, 47);
		frame.getContentPane().add(lblControlParaCentro);
		
		JButton btnNewButton = new JButton("ATRAS");
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MenuSecretaria mp = new MenuSecretaria();
				mp.mostrarMenuSecretaria();
				frame.setVisible(false); // cerramos la ventana Inicio
			}
		});
		btnNewButton.setBackground(new Color(0, 206, 209));
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 18));
		btnNewButton.setBounds(24, 290, 113, 47);
		frame.getContentPane().add(btnNewButton);
		
		JEditorPane dtrpnCentrosDeEmergencia = new JEditorPane();
		dtrpnCentrosDeEmergencia.setEditable(false);
		dtrpnCentrosDeEmergencia.setText("\r\n            Centros de Emergencia Ciudad La Paz\r\n            ******************************\r\n\r\n  1. Miraflores\t        - \tTelf. 22210584\r\n  2. Sopocachi\t        -\tTelf.22210896\r\n  3. Villa F\u00E1tima        -\tTelf.22223412\r\n  4. Obrajes\t        -\tTelf.22244889\r\n  5. Irpavi\t        -\tTelf.22216780\r\n  6. Cota Cota\t        -\tTelf.22210032");
		dtrpnCentrosDeEmergencia.setBackground(new Color(224, 255, 255));
		dtrpnCentrosDeEmergencia.setFont(new Font("Verdana", Font.PLAIN, 14));
		dtrpnCentrosDeEmergencia.setBounds(84, 58, 417, 216);
		frame.getContentPane().add(dtrpnCentrosDeEmergencia);
	}
}
