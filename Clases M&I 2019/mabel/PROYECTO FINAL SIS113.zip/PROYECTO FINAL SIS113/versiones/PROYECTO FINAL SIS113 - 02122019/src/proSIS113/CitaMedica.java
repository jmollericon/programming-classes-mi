package proSIS113;
public class CitaMedica {
	// atributos
	private String ciPaciente;
	private String nomPaciente;
	private String especialidad;
	private String especialista;
	private String fecha;
	private String hora;

	// constructor con parametros
	public CitaMedica(String ciPaciente, String nomPaciente, String especialidad, String especialista, String fecha, String hora) {
		this.ciPaciente = ciPaciente;
		this.nomPaciente = nomPaciente;
		this.especialidad = especialidad;
		this.especialista = especialista;
		this.fecha = fecha;
		this.hora = hora;
	}

	public String getespecialidad() {
		return especialidad;
	}

	public void setespecialidad(String especialidad) {
		this.especialidad = especialidad;
	}

	public String getespecialista() {
		return especialista;
	}

	public void setespecialista(String especialista) {
		this.especialista = especialista;
	}

	public String getfecha() {
		return fecha;
	}

	public void setfecha(String fecha) {
		this.fecha = fecha;
	}

	public String gethora() {
		return hora;
	}

	public void sethora(String hora) {
		this.hora = hora;
	}

	public String getCiPaciente() {
		return ciPaciente;
	}

	public void setCiPaciente(String ciPaciente) {
		this.ciPaciente = ciPaciente;
	}

	public String getNomPaciente() {
		return nomPaciente;
	}

	public void setNomPaciente(String nomPaciente) {
		this.nomPaciente = nomPaciente;
	}
	
}
