package proSIS113;
public class Paciente {
	// atributos
	private String ci;
	private String apPaterno;
	private String apMaterno;
	private String nombres;
	private String fechaNac;
	private String celular;
	private String tipoSangre;
	private String alergias;
	private String nomRef;
	private String celRef;

	// constructor con parametros
	public Paciente(String ci, String apPaterno, String apMaterno, String nombres,
			String fechaNac, String celular, String tipoSangre,
			String alergias, String nomRef, String celRef) {
		super();
		this.apPaterno = apPaterno;
		this.apMaterno = apMaterno;
		this.nombres = nombres;
		this.ci = ci;
		this.fechaNac = fechaNac;
		this.celular = celular;
		this.tipoSangre = tipoSangre;
		this.alergias = alergias;
		this.nomRef = nomRef;
		this.celRef = celRef;
	}

	public String getApPaterno() {
		return apPaterno;
	}

	public void setApPaterno(String apPaterno) {
		this.apPaterno = apPaterno;
	}

	public String getApMaterno() {
		return apMaterno;
	}

	public void setApMaterno(String apMaterno) {
		this.apMaterno = apMaterno;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getCi() {
		return ci;
	}

	public void setCi(String ci) {
		this.ci = ci;
	}

	public String getFechaNac() {
		return fechaNac;
	}

	public void setFechaNac(String fechaNac) {
		this.fechaNac = fechaNac;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(String celular) {
		this.celular = celular;
	}

	public String getTipoSangre() {
		return tipoSangre;
	}

	public void setTipoSangre(String tipoSangre) {
		this.tipoSangre = tipoSangre;
	}

	public String getAlergias() {
		return alergias;
	}

	public void setAlergias(String alergias) {
		this.alergias = alergias;
	}

	public String getNomRef() {
		return nomRef;
	}

	public void setNomRef(String nomRef) {
		this.nomRef = nomRef;
	}

	public String getCelRef() {
		return celRef;
	}

	public void setCelRef(String celRef) {
		this.celRef = celRef;
	}
	
	
	

}
