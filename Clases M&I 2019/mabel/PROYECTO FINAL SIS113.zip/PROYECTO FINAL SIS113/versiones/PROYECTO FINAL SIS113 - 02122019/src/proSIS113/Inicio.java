package proSIS113;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.SwingConstants;

public class Inicio {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inicio window = new Inicio();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Inicio() {

		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(102, 205, 170));
		frame.setBounds(350, 180, 600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblControlParaCentro = new JLabel("CONTROL PARA");
		lblControlParaCentro.setHorizontalAlignment(SwingConstants.CENTER);
		lblControlParaCentro.setForeground(new Color(0, 128, 128));
		lblControlParaCentro.setFont(new Font("Verdana", Font.BOLD, 26));
		lblControlParaCentro.setBounds(0, 21, 584, 59);
		frame.getContentPane().add(lblControlParaCentro);
		
		JButton btnNewButton = new JButton("INICIAR");
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MenuPrincipal mp = new MenuPrincipal();
				mp.mostrarMenuPrincipal();
				frame.setVisible(false); // cerramos la ventana Inicio
			}
		});
		btnNewButton.setBackground(new Color(0, 206, 209));
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 18));
		btnNewButton.setBounds(403, 248, 153, 82);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblCentroMdico = new JLabel("CENTRO M\u00C9DICO");
		lblCentroMdico.setHorizontalAlignment(SwingConstants.CENTER);
		lblCentroMdico.setForeground(new Color(0, 128, 128));
		lblCentroMdico.setFont(new Font("Verdana", Font.BOLD, 26));
		lblCentroMdico.setBounds(0, 59, 584, 59);
		frame.getContentPane().add(lblCentroMdico);
		
		JLabel lblUniversidad = new JLabel("UNIVERSIDAD");
		lblUniversidad.setHorizontalAlignment(SwingConstants.CENTER);
		lblUniversidad.setForeground(new Color(224, 255, 255));
		lblUniversidad.setFont(new Font("Verdana", Font.BOLD, 26));
		lblUniversidad.setBounds(0, 129, 405, 59);
		frame.getContentPane().add(lblUniversidad);
		
		JLabel lblCatlica = new JLabel("CAT\u00D3LICA");
		lblCatlica.setHorizontalAlignment(SwingConstants.CENTER);
		lblCatlica.setForeground(new Color(224, 255, 255));
		lblCatlica.setFont(new Font("Verdana", Font.BOLD, 26));
		lblCatlica.setBounds(0, 163, 405, 59);
		frame.getContentPane().add(lblCatlica);
		
		JLabel lblBoliviana = new JLabel("BOLIVIANA");
		lblBoliviana.setHorizontalAlignment(SwingConstants.CENTER);
		lblBoliviana.setForeground(new Color(224, 255, 255));
		lblBoliviana.setFont(new Font("Verdana", Font.BOLD, 26));
		lblBoliviana.setBounds(0, 199, 405, 59);
		frame.getContentPane().add(lblBoliviana);
		
		JLabel lblUnivMabelAguilera = new JLabel("Univ. Mabel Aguilera");
		lblUnivMabelAguilera.setHorizontalAlignment(SwingConstants.CENTER);
		lblUnivMabelAguilera.setForeground(new Color(0, 139, 139));
		lblUnivMabelAguilera.setFont(new Font("Verdana", Font.BOLD, 20));
		lblUnivMabelAguilera.setBounds(0, 269, 405, 59);
		frame.getContentPane().add(lblUnivMabelAguilera);
	}
}
