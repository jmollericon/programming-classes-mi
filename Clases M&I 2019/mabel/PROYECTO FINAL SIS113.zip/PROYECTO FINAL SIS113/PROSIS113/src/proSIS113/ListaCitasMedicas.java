package proSIS113;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.SwingConstants;
import javax.swing.JTextPane;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class ListaCitasMedicas {

	private JFrame frame;

	// ---- para conexion a la base de datos ------
	static Conexion con = new Conexion();
	static Connection cn = null;
	static Statement stm = null;
	static ResultSet rs = null;
	
	private int nroCitasMedicas = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListaCitasMedicas window = new ListaCitasMedicas();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ListaCitasMedicas() {
		int n = 100; // capacidad en n�mero de cuentas
    	//leerArchivoCitasMedicas(cm);
		initialize();
	}
	public void mostrarListaCitasMedicas(){
		this.frame.setVisible(true); // mostrar ventana
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.BLUE);
		frame.setBounds(350, 180, 600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblControlParaCentro = new JLabel("LISTA DE PACIENTES REGISTRADOS");
		lblControlParaCentro.setHorizontalAlignment(SwingConstants.CENTER);
		lblControlParaCentro.setForeground(Color.WHITE);
		lblControlParaCentro.setFont(new Font("Verdana", Font.BOLD, 20));
		lblControlParaCentro.setBounds(0, 0, 584, 47);
		frame.getContentPane().add(lblControlParaCentro);
		
		JButton btnNewButton = new JButton("ATRAS");
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MenuSecretaria mp = new MenuSecretaria();
				mp.mostrarMenuSecretaria();
				frame.setVisible(false); // cerramos la ventana Inicio
			}
		});
		btnNewButton.setBackground(new Color(0, 206, 209));
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 18));
		btnNewButton.setBounds(24, 290, 113, 47);
		frame.getContentPane().add(btnNewButton);
		
		JTextPane textPane = new JTextPane();
		textPane.setFont(new Font("Verdana", Font.PLAIN, 9));
		textPane.setBackground(new Color(224, 255, 255));
		textPane.setEditable(false);
		textPane.setBounds(10, 41, 564, 237);
		frame.getContentPane().add(textPane);

    	String lista = " #    DATOS PACIENTE\t\tATENCI�N EN:\t\tFECHA.\n";
    		  lista += " =    ==================\t============ \t\t========\n";
    		  
		// ---- conexion a la base de datos y obtencion de datos ------
		try {
			cn = con.getConexionMYSQL();
			stm = (Statement) cn.createStatement();
			rs = stm.executeQuery("SELECT * FROM citasmedicas"); // consulta sql (consulta a la base de datos)
			int i=1;
			while(rs.next()){
				int idCi 		= rs.getInt(1);
				String esp 		= rs.getString(2);
				String doc 		= rs.getString(3);
				String feh 		= rs.getString(4);
				
	    		lista += " "+(i++)+":  "+idCi+"\t\t\t"+esp+" "+"\t"+feh+"\n";
	    		lista += "     \t\t"+doc+"\n";				
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			try {
				if(rs != null) rs.close();
				if(stm != null) stm.close();
				if(cn != null) cn.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}    		  
    		  
    		  
    	/*for (int i=0; i<nroCitasMedicas; i++) {
    		//System.out.println(p[i].getApPaterno()+"\t"+p[i].getApMaterno()+"\t"+p[i].getNombres());
    		//lista += " "+(i+1)+"  "+cm[i].getCiPaciente()+"\t"+cm[i].getNomPaciente()+" "+cm[i].getespecialidad()+" "+cm[i].getespecialista()+"\t"+cm[i].getfecha()+" "+cm[i].gethora()+"\n";

    	}*/
		textPane.setText(lista);
	}
}