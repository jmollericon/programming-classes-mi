package proSIS113;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.SwingConstants;

import com.mysql.jdbc.Connection;

public class Inicio {

	private JFrame frame;
	Conexion con = new Conexion();
	Connection cn = null;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inicio window = new Inicio();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Inicio() {
		cn = con.getConexionMYSQL();
		initialize();
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(0, 0, 255));
		frame.setBounds(350, 180, 600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblControlParaCentro = new JLabel("CONTROL PARA");
		lblControlParaCentro.setHorizontalAlignment(SwingConstants.CENTER);
		lblControlParaCentro.setForeground(new Color(255, 255, 255));
		lblControlParaCentro.setFont(new Font("Verdana", Font.BOLD, 28));
		lblControlParaCentro.setBounds(0, 112, 584, 59);
		frame.getContentPane().add(lblControlParaCentro);
		
		JButton btnNewButton = new JButton("INICIAR");
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Login mp = new Login();
				mp.mostrarMenuLogin();
				frame.setVisible(false); // cerramos la ventana Inicio
			}
		});
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 18));
		btnNewButton.setBounds(403, 248, 153, 82);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblCentroMdico = new JLabel("CENTRO M\u00C9DICO");
		lblCentroMdico.setHorizontalAlignment(SwingConstants.CENTER);
		lblCentroMdico.setForeground(new Color(255, 255, 255));
		lblCentroMdico.setFont(new Font("Verdana", Font.BOLD, 28));
		lblCentroMdico.setBounds(10, 139, 584, 98);
		frame.getContentPane().add(lblCentroMdico);
		
		JLabel lblUnivMabelAguilera = new JLabel("estudiante: Mabel C. Aguilera C.\r\n");
		lblUnivMabelAguilera.setHorizontalAlignment(SwingConstants.CENTER);
		lblUnivMabelAguilera.setForeground(new Color(255, 255, 255));
		lblUnivMabelAguilera.setFont(new Font("Verdana", Font.ITALIC, 13));
		lblUnivMabelAguilera.setBounds(10, 304, 233, 46);
		frame.getContentPane().add(lblUnivMabelAguilera);
	}
}
