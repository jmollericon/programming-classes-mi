package proSIS113;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.SwingConstants;
import javax.swing.UIManager;

import java.awt.SystemColor;

public class MenuGerente {

	private JFrame frame;
	private String apPatSecre;
	private String nomsSecre;
	private String idCiSecre;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuGerente window = new MenuGerente();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the application.
	 */
	public MenuGerente() {
		initialize();
	}
	public MenuGerente(String apPat, String nom, String idCi) {
		apPatSecre 	= apPat;
		nomsSecre 	= nom;
		idCiSecre 	= idCi;
		initialize();
	}
	public void mostrarMenuSecretaria(){
		this.frame.setVisible(true); // mostrar ventana
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.BLUE);
		frame.setBounds(350, 180, 600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblControlParaCentro = new JLabel("SELECCIONE LA OPERACION A REALIZAR");
		lblControlParaCentro.setHorizontalAlignment(SwingConstants.CENTER);
		lblControlParaCentro.setForeground(Color.WHITE);
		lblControlParaCentro.setFont(new Font("Verdana", Font.BOLD, 20));
		lblControlParaCentro.setBounds(0, 0, 584, 43);
		frame.getContentPane().add(lblControlParaCentro);
		
		/*JButton btnNewButton = new JButton("DOCTORES");
		btnNewButton.setToolTipText("");
		btnNewButton.setForeground(new Color(51, 51, 204));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				RegistrarPaciente rp = new RegistrarPaciente();
				rp.mostrarRegistrarPaciente();
				frame.setVisible(false); // cerramos la ventana Inicio
			}
		});
		btnNewButton.setBackground(new Color(224, 255, 255));
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 14));
		btnNewButton.setBounds(111, 42, 363, 47);
		frame.getContentPane().add(btnNewButton);
		*/
		JButton btnPacientesRegistradoslista = new JButton("ESTADO CITAS M\u00C9DICAS");
		btnPacientesRegistradoslista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EstadoCitasMedicas ecm = new EstadoCitasMedicas();
				ecm.mostrarEstadoCitasMedicas();
				frame.setVisible(false);
			}
		});
		btnPacientesRegistradoslista.setForeground(new Color(51, 51, 204));
		btnPacientesRegistradoslista.setFont(new Font("Verdana", Font.BOLD, 14));
		btnPacientesRegistradoslista.setBackground(new Color(224, 255, 255));
		btnPacientesRegistradoslista.setBounds(111, 93, 363, 43);
		frame.getContentPane().add(btnPacientesRegistradoslista);
		
		JButton btnRegistrarCitaMdica = new JButton("CITAS M\u00C9DICAS ATENDIDAS");
		btnRegistrarCitaMdica.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CitasMedicasAtendidas cma = new CitasMedicasAtendidas();
				cma.mostrarCitasMedicasAtendidas();
				frame.setVisible(false);
			}
		});
		btnRegistrarCitaMdica.setForeground(new Color(51, 51, 204));
		btnRegistrarCitaMdica.setFont(new Font("Verdana", Font.BOLD, 14));
		btnRegistrarCitaMdica.setBackground(new Color(224, 255, 255));
		btnRegistrarCitaMdica.setBounds(111, 141, 363, 43);
		frame.getContentPane().add(btnRegistrarCitaMdica);
		
		/*JButton btnTelefonosDeEmergencia = new JButton("TELEFONOS DE EMERGENCIA");
		btnTelefonosDeEmergencia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TelefonosEmergencia te = new TelefonosEmergencia();
				te.mostrarTelefonosEmergencia();
				frame.setVisible(false);
			}
		});
		btnTelefonosDeEmergencia.setForeground(new Color(51, 51, 204));
		btnTelefonosDeEmergencia.setFont(new Font("Verdana", Font.BOLD, 14));
		btnTelefonosDeEmergencia.setBackground(new Color(224, 255, 255));
		btnTelefonosDeEmergencia.setBounds(111, 237, 363, 43);
		frame.getContentPane().add(btnTelefonosDeEmergencia);
		*/
		JButton btnSalir = new JButton("SALIR");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null, "Cerrando Sesion.\nGracias por su visita.");
				Login lo =  new Login();
				lo.mostrarMenuLogin();
				frame.setVisible(false); // cerramos la ventana Menu principal
			}
		});
		btnSalir.setForeground(Color.BLUE);
		btnSalir.setFont(new Font("Verdana", Font.BOLD, 18));
		btnSalir.setBackground(new Color(0, 206, 209));
		btnSalir.setBounds(33, 291, 113, 47);
		frame.getContentPane().add(btnSalir);
		
		/*JButton btnCitasMdicasRegistradas = new JButton("CITAS M\u00C9DICAS REGISTRADAS (LISTA)");
		btnCitasMdicasRegistradas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ListaCitasMedicas lcm = new ListaCitasMedicas();
				lcm.mostrarListaCitasMedicas();
				frame.setVisible(false);
			}
		});
		btnCitasMdicasRegistradas.setForeground(new Color(51, 51, 204));
		btnCitasMdicasRegistradas.setFont(new Font("Verdana", Font.BOLD, 14));
		btnCitasMdicasRegistradas.setBackground(new Color(224, 255, 255));
		btnCitasMdicasRegistradas.setBounds(111, 189, 363, 43);
		frame.getContentPane().add(btnCitasMdicasRegistradas);
		*/
	}
	void mostrarMenuGerente(){
		frame.setVisible(true);
	}
}
