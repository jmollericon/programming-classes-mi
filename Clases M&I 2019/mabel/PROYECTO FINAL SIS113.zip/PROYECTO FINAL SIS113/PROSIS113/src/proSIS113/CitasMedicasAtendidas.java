package proSIS113;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.SwingConstants;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import javax.swing.JTextField;
import javax.swing.JPasswordField;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import java.awt.Canvas;

public class CitasMedicasAtendidas {

	private JFrame frame;
	private JLabel label;
	private JLabel label_1;
	private JLabel label_2;
	private JLabel label_3;
	// ---- para conexion a la base de datos ------
	static Conexion con = new Conexion();
	static Connection cn = null;
	static Statement stm = null;
	static ResultSet rs = null;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CitasMedicasAtendidas window = new CitasMedicasAtendidas();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CitasMedicasAtendidas() {
		initialize();
		datosEstadisticosCitasMedicas();
	}
	public void mostrarCitasMedicasAtendidas(){
		this.frame.setVisible(true); // mostrar ventana
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(0, 0, 255));
		frame.setBounds(350, 180, 600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblControlParaCentro = new JLabel("Citas Medicas Atendidas");
		lblControlParaCentro.setHorizontalAlignment(SwingConstants.CENTER);
		lblControlParaCentro.setForeground(new Color(255, 255, 255));
		lblControlParaCentro.setFont(new Font("Verdana", Font.BOLD, 28));
		lblControlParaCentro.setBounds(0, 11, 584, 52);
		frame.getContentPane().add(lblControlParaCentro);
		
		JButton btnNewButton = new JButton("ATRAS");
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MenuGerente mg = new MenuGerente();
				mg.mostrarMenuGerente();
				frame.setVisible(false);
			}
		});
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 18));
		btnNewButton.setBounds(28, 291, 119, 45);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblUsuario = new JLabel("Total de citas m\u00E9dicas atendidas:");
		lblUsuario.setForeground(Color.WHITE);
		lblUsuario.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblUsuario.setBounds(28, 58, 224, 35);
		frame.getContentPane().add(lblUsuario);
		
		label = new JLabel("");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label.setBounds(184, 137, 149, 26);
		frame.getContentPane().add(label);
		
		label_1 = new JLabel("");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_1.setBounds(262, 58, 179, 35);
		frame.getContentPane().add(label_1);
		
		label_2 = new JLabel("");
		label_2.setForeground(Color.WHITE);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_2.setBounds(184, 174, 149, 26);
		frame.getContentPane().add(label_2);
		
		label_3 = new JLabel("");
		label_3.setForeground(Color.WHITE);
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_3.setBounds(184, 210, 159, 26);
		frame.getContentPane().add(label_3);
		
	}
	void datosEstadisticosCitasMedicas(){
		int cg=0;
		int id=0;
		String nEspe;
		String espe[] = new String[25];
		int cEspe[] = new int[25];
		// ---- conexion a la base de datos y obtencion de datos ------
		try {
			cn = con.getConexionMYSQL();
			stm = (Statement) cn.createStatement();

			// Se obtiene las especialidades
			rs = stm.executeQuery("SELECT * FROM especialidades"); // consulta sql (consulta a la base de datos)
			while(rs.next()){
				id 			= rs.getInt(1);
				nEspe		= rs.getString(2);
				espe[id]	= nEspe; 
			}
			
			// Se obtine todas las citas m�dicas registradas
			rs = stm.executeQuery("SELECT * FROM citasmedicas"); // consulta sql (consulta a la base de datos)
			while(rs.next()){
				int estado = rs.getInt(5);
				if(estado == 1){ // CITAS MEDICAS ATENDIDAS
					cg++;
					for (int i = 1; i <= id; i++) {
						if(espe[i].equals(rs.getString(2))){
							cEspe[i]++;
						}
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			try {
				if(rs != null) rs.close();
				if(stm != null) stm.close();
				if(cn != null) cn.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}

		// Jfreechart
		DefaultPieDataset dataset = new DefaultPieDataset();
		for (int i = 1; i <= id; i++) {
			dataset.setValue(espe[i], new Double(cEspe[i]));
		}
		
		label_1.setText(cg+"");
    
        JFreeChart graficoEst = ChartFactory.createPieChart(// char t
	        "Citas M�dicas\nTotal = "+cg,	// title                                                                                                                                        
	        dataset, 		// data
	        true, 			// include legend
	        true, false );
        ChartPanel panelGrafico= new ChartPanel(graficoEst);
        panelGrafico.setBounds(178, 100, 380, 236);
        frame.getContentPane().add(panelGrafico);		
	}
}

