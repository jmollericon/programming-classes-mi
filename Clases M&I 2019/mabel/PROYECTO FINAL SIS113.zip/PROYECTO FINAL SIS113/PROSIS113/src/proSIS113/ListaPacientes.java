package proSIS113;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.SwingConstants;
import javax.swing.JFormattedTextField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JTextPane;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class ListaPacientes {

	private JFrame frame;
	
	// ---- para conexion a la base de datos ------
	static Conexion con = new Conexion();
	static Connection cn = null;
	static Statement stm = null;
	static ResultSet rs = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListaPacientes window = new ListaPacientes();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ListaPacientes() {
		initialize();
	}
	public void mostrarListaPacientes(){
		this.frame.setVisible(true); // mostrar ventana
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.BLUE);
		frame.setBounds(350, 180, 600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblControlParaCentro = new JLabel("LISTA DE PACIENTES REGISTRADOS");
		lblControlParaCentro.setHorizontalAlignment(SwingConstants.CENTER);
		lblControlParaCentro.setForeground(Color.WHITE);
		lblControlParaCentro.setFont(new Font("Verdana", Font.BOLD, 20));
		lblControlParaCentro.setBounds(0, 0, 584, 47);
		frame.getContentPane().add(lblControlParaCentro);
		
		JButton btnNewButton = new JButton("ATRAS");
		btnNewButton.setForeground(new Color(51, 51, 204));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MenuSecretaria mp = new MenuSecretaria();
				mp.mostrarMenuSecretaria();
				frame.setVisible(false); // cerramos la ventana Inicio
			}
		});
		btnNewButton.setBackground(new Color(0, 206, 209));
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 18));
		btnNewButton.setBounds(10, 303, 113, 47);
		frame.getContentPane().add(btnNewButton);
		
		JTextPane textPane = new JTextPane();
		textPane.setBackground(new Color(224, 255, 255));
		textPane.setFont(new Font("Verdana", Font.PLAIN, 11));
		textPane.setEditable(false);
		textPane.setBounds(10, 44, 564, 248);
		frame.getContentPane().add(textPane);
		
    	String lista = " #   DATOS PACIENTE\t\tFECHA NAC.    PERSONA REF.\tOTROS DATOS\n";
    		  lista += " =   ================\t========    ==========\t========\n";
    		  
	// ---- conexion a la base de datos y obtencion de datos ------
		try {
			cn = con.getConexionMYSQL();
			stm = (Statement) cn.createStatement();
			rs = stm.executeQuery("SELECT * FROM pacientes"); // consulta sql (consulta a la base de datos)
			int i=1;
			while(rs.next()){
				int idCi 		= rs.getInt(1);
				String nom 		= rs.getString(2);
				String apP 		= rs.getString(3);
				String apM 		= rs.getString(4);
				String fNa 		= rs.getString(5);
				int cel 		= rs.getInt(6);
				
				String tSa 		= rs.getString(7);
				String alg 		= rs.getString(8);
				String pRf 		= rs.getString(9);
				int cRf			= rs.getInt(10);
				
	    		lista += " "+(i++)+":  CI: "+idCi+" - "+apP+"\t"+fNa+"\t    "+pRf+"\t"+tSa+" (tipo sangre)\n";
	    		lista += "      "+apM+' '+nom+"       \t"+cel+"\t    Cel: "+cRf+"\t"+alg+" (alergia)\n";
				
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			try {
				if(rs != null) rs.close();
				if(stm != null) stm.close();
				if(cn != null) cn.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
    		  
    		  
    		  
    	/*for (int i = 0; i < nroPacientes; i++) {
    		//System.out.println(p[i].getApPaterno()+"\t"+p[i].getApMaterno()+"\t"+p[i].getNombres());
    		//lista += " "+(i+1)+"  "+p[i].getCi()+"\t"+p[i].getApPaterno()+" "+p[i].getApMaterno()+" "+p[i].getNombres()+"\t"+p[i].getFechaNac()+"   "+p[i].getCelular()+"   "+p[i].getCelRef()+"\n";

    	}*/
		textPane.setText(lista);
		
	}


}